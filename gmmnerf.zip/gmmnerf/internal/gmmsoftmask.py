"""Computes gmm mask."""
from typing import Mapping, Tuple

from jax import lax
from jax import device_put
import jax.numpy as jnp
import jax
from jax import random
# from sklearn.mixture import GaussianMixture
import numpy as np
import jax.numpy as jnp
from sklearn.utils.extmath import row_norms


def smoothed_filter_core(smoothed_filter_size, residual):
    # Apply fxf (3x3, 5×5, 7×7...) box filter 'window' for smoothing (diffusion).
    f = smoothed_filter_size
    window = jnp.ones((1, 1, f, f)) / (f * f)
    residual_blur = lax.conv(
        jnp.transpose(residual, [0, 3, 1, 2]), window, (1, 1), 'SAME'
    )
    residual_blur = jnp.transpose(residual_blur, [0, 2, 3, 1])
    return residual_blur
    
def patch_apart(image_height, image_width, tiny_patch_size, residual):
  '''
  把residual图像分成tiny patch
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  '''
  ###############
  # 生成固定的patch坐标，固定是为了方便输出residual的mask
  # 计算patch的行数和列数
  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T
  
  # 固定坐标的 patch 坐标
  fixed_patch_coordinates = np.array(list(patch_coordinates))

  # 计算对应的切片索引
  x_indices = (fixed_patch_coordinates[:, 0])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]
  y_indices = (fixed_patch_coordinates[:, 1])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]

  # 提取小图像块
  residual_patches = residual[:, y_indices[:, :, np.newaxis], x_indices[:, np.newaxis, :]]
  return residual_patches    


def reconstruct_patch(image_height, image_width, tiny_patch_size, shape0, reshaped_prob):
  '''
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  shape0: residual有几个patch, 取决于卡数量和batch size
  reshaped_prob: 要 reshape mask 的概率值
  '''
  # 16个patch。每个patch里有若干小patch
  length = reshaped_prob.shape[0]
  subset_data = reshaped_prob.reshape(shape0, length//shape0)

  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T

  # 将还原的图像块放入对应的位置
  _patch = jnp.zeros((shape0, image_height, image_width))  # 初始化一个空白图像
  for i in range(len(patch_coordinates)):
      # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
      x, y = patch_coordinates[i]
      tiny_patch = jnp.tile(subset_data[:, i][...,np.newaxis, np.newaxis], (tiny_patch_size, tiny_patch_size))
    #   _patch[:, y:y+patch_size, x:x+patch_size] = tiny_patch
      _patch = _patch.at[:, y:y+tiny_patch_size, x:x+tiny_patch_size].set(tiny_patch)
  return _patch

def _asarray_validated(a, check_finite=True,
                       sparse_ok=False, objects_ok=False, mask_ok=False,
                       as_inexact=False):
    """
    Helper function for SciPy argument validation.

    Many SciPy linear algebra functions do support arbitrary array-like
    input arguments. Examples of commonly unsupported inputs include
    matrices containing inf/nan, sparse matrix representations, and
    matrices with complicated elements.

    Parameters
    ----------
    a : array_like
        The array-like input.
    check_finite : bool, optional
        Whether to check that the input matrices contain only finite numbers.
        Disabling may give a performance gain, but may result in problems
        (crashes, non-termination) if the inputs do contain infinities or NaNs.
        Default: True
    sparse_ok : bool, optional
        True if scipy sparse matrices are allowed.
    objects_ok : bool, optional
        True if arrays with dype('O') are allowed.
    mask_ok : bool, optional
        True if masked arrays are allowed.
    as_inexact : bool, optional
        True to convert the input array to a np.inexact dtype.

    Returns
    -------
    ret : ndarray
        The converted validated array.

    """
    if not sparse_ok:
        import scipy.sparse
        if scipy.sparse.issparse(a):
            msg = ('Sparse matrices are not supported by this function. '
                   'Perhaps one of the scipy.sparse.linalg functions '
                   'would work instead.')
            raise ValueError(msg)
    if not mask_ok:
        if np.ma.isMaskedArray(a):
            raise ValueError('masked arrays are not supported')
    toarray = jnp.asarray_chkfinite if check_finite else jnp.asarray
    a = toarray(a)
    if not objects_ok:
        if a.dtype is jnp.dtype('O'):
            raise ValueError('object arrays are not supported')
    if as_inexact:
        if not jnp.issubdtype(a.dtype, jnp.inexact):
            a = toarray(a, dtype=jnp.float_)
    return a


def logsumexp(a, axis=None, b=None, keepdims=False, return_sign=False):
    """Compute the log of the sum of exponentials of input elements.

    Parameters
    ----------
    a : array_like
        Input array.
    axis : None or int or tuple of ints, optional
        Axis or axes over which the sum is taken. By default `axis` is None,
        and all elements are summed.

        .. versionadded:: 0.11.0
    b : array-like, optional
        Scaling factor for exp(`a`) must be of the same shape as `a` or
        broadcastable to `a`. These values may be negative in order to
        implement subtraction.

        .. versionadded:: 0.12.0
    keepdims : bool, optional
        If this is set to True, the axes which are reduced are left in the
        result as dimensions with size one. With this option, the result
        will broadcast correctly against the original array.

        .. versionadded:: 0.15.0
    return_sign : bool, optional
        If this is set to True, the result will be a pair containing sign
        information; if False, results that are negative will be returned
        as NaN. Default is False (no sign information).

        .. versionadded:: 0.16.0

    Returns
    -------
    res : ndarray
        The result, ``np.log(np.sum(np.exp(a)))`` calculated in a numerically
        more stable way. If `b` is given then ``np.log(np.sum(b*np.exp(a)))``
        is returned.
    sgn : ndarray
        If return_sign is True, this will be an array of floating-point
        numbers matching res and +1, 0, or -1 depending on the sign
        of the result. If False, only one result is returned.

    See Also
    --------
    numpy.logaddexp, numpy.logaddexp2

    Notes
    -----
    NumPy has a logaddexp function which is very similar to `logsumexp`, but
    only handles two arguments. `logaddexp.reduce` is similar to this
    function, but may be less stable.

    Examples
    --------
    >>> import numpy as np
    >>> from scipy.special import logsumexp
    >>> a = np.arange(10)
    >>> logsumexp(a)
    9.4586297444267107
    >>> np.log(np.sum(np.exp(a)))
    9.4586297444267107

    With weights

    >>> a = np.arange(10)
    >>> b = np.arange(10, 0, -1)
    >>> logsumexp(a, b=b)
    9.9170178533034665
    >>> np.log(np.sum(b*np.exp(a)))
    9.9170178533034647

    Returning a sign flag

    >>> logsumexp([1,2],b=[1,-1],return_sign=True)
    (1.5413248546129181, -1.0)

    Notice that `logsumexp` does not directly support masked arrays. To use it
    on a masked array, convert the mask into zero weights:

    >>> a = np.ma.array([np.log(2), 2, np.log(3)],
    ...                  mask=[False, True, False])
    >>> b = (~a.mask).astype(int)
    >>> logsumexp(a.data, b=b), np.log(5)
    1.6094379124341005, 1.6094379124341005

    """
    a = _asarray_validated(a, check_finite=False)
    if b is not None:
        a, b = jnp.broadcast_arrays(a, b)
        if jnp.any(b == 0):
            a = a + 0.  # promote to at least float
            # a[b == 0] = -jnp.inf
            # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
            a = a.at[b == 0].set(-jnp.inf)

    a_max = jnp.amax(a, axis=axis, keepdims=True)

    if a_max.ndim > 0:
        # a_max[~jnp.isfinite(a_max)] = 0
        # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
        # a_max = a_max.at[~jnp.isfinite(a_max)].set(0)
        # 具体化布尔索引
        is_finite_mask = lax.convert_element_type(~jnp.isfinite(a_max), np.int32)
        # 使用具体化的布尔索引进行替换
        a_max = a_max.at[is_finite_mask].set(0)
        
    elif not jnp.isfinite(a_max):
        a_max = 0

    if b is not None:
        b = jnp.asarray(b)
        tmp = b * jnp.exp(a - a_max)
    else:
        tmp = jnp.exp(a - a_max)

    # suppress warnings about log of zero
    with np.errstate(divide='ignore'):
        s = jnp.sum(tmp, axis=axis, keepdims=keepdims)
        if return_sign:
            sgn = jnp.sign(s)
            s *= sgn  # /= makes more sense but we need zero -> zero
        out = jnp.log(s)

    if not keepdims:
        a_max = jnp.squeeze(a_max, axis=axis)
    out += a_max

    if return_sign:
        return out, sgn
    else:
        return out

######
#### 
# Gaussian mixture probability estimators
def _compute_log_det_cholesky(matrix_chol, covariance_type, n_features):
    """Compute the log-det of the cholesky decomposition of matrices.

    Parameters
    ----------
    matrix_chol : array-like
        Cholesky decompositions of the matrices.
        'full' : shape of (n_components, n_features, n_features)
        'tied' : shape of (n_features, n_features)
        'diag' : shape of (n_components, n_features)
        'spherical' : shape of (n_components,)

    covariance_type : {'full', 'tied', 'diag', 'spherical'}

    n_features : int
        Number of features.

    Returns
    -------
    log_det_precision_chol : array-like of shape (n_components,)
        The determinant of the precision matrix for each component.
    """
    # if covariance_type == 0: #"full"
    # assert covariance_type == 0, "covariance_type == \"full\" !"
    n_components, _, _ = matrix_chol.shape
    log_det_chol = jnp.sum(
        jnp.log(matrix_chol.reshape(n_components, -1)[:, :: n_features + 1]), 1
    )

    # elif covariance_type == 1: #"tied"
    #     log_det_chol = jnp.sum(jnp.log(jnp.diag(matrix_chol)))

    # elif covariance_type == 2: #"diag"
    #     log_det_chol = jnp.sum(jnp.log(matrix_chol), axis=1)

    # else:
    #     log_det_chol = n_features * (jnp.log(matrix_chol))

    return log_det_chol

def _estimate_log_gaussian_prob(X, means, precisions_chol, covariance_type):
    """Estimate the log Gaussian probability.

    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)

    means : array-like of shape (n_components, n_features)

    precisions_chol : array-like
        Cholesky decompositions of the precision matrices.
        'full' : shape of (n_components, n_features, n_features)
        'tied' : shape of (n_features, n_features)
        'diag' : shape of (n_components, n_features)
        'spherical' : shape of (n_components,)

    covariance_type : {'full', 'tied', 'diag', 'spherical'}

    Returns
    -------
    log_prob : array, shape (n_samples, n_components)
    """
    n_samples, n_features = X.shape
    n_components, _ = means.shape
    # The determinant of the precision matrix from the Cholesky decomposition
    # corresponds to the negative half of the determinant of the full precision
    # matrix.
    # In short: det(precision_chol) = - det(precision) / 2
    log_det = _compute_log_det_cholesky(precisions_chol, covariance_type, n_features)

    # if covariance_type == 0: #"full"
    # assert covariance_type == 0, "covariance_type == \"full\" !"
    log_prob = jnp.empty((n_samples, n_components))
    for k, (mu, prec_chol) in enumerate(zip(means, precisions_chol)):
        y = jnp.dot(X, prec_chol) - jnp.dot(mu, prec_chol)
        # log_prob[:, k] = jnp.sum(jnp.square(y), axis=1)
        # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
        log_prob = log_prob.at[:, k].set(jnp.sum(jnp.square(y), axis=1))
            

    # elif covariance_type == 1: #"tied"
    #     log_prob = jnp.empty((n_samples, n_components))
    #     for k, mu in enumerate(means):
    #         y = jnp.dot(X, precisions_chol) - jnp.dot(mu, precisions_chol)
    #         log_prob[:, k] = jnp.sum(jnp.square(y), axis=1)

    # elif covariance_type == 2: #"diag"
    #     precisions = precisions_chol**2
    #     log_prob = (
    #         jnp.sum((means**2 * precisions), 1)
    #         - 2.0 * jnp.dot(X, (means * precisions).T)
    #         + jnp.dot(X**2, precisions.T)
    #     )

    # elif covariance_type == 3: #"spherical"
    #     precisions = precisions_chol**2
    #     log_prob = (
    #         jnp.sum(means**2, 1) * precisions
    #         - 2 * jnp.dot(X, means.T * precisions)
    #         + jnp.outer(row_norms(X, squared=True), precisions)
    #     )
    # Since we are using the precision of the Cholesky decomposition,
    # `- 0.5 * log_det_precision` becomes `+ log_det_precision_chol`
    return -0.5 * (n_features * jnp.log(2 * jnp.pi) + log_prob) + log_det


def _estimate_log_weights(weights_):
        return jnp.log(weights_)
    
def _estimate_weighted_log_prob(X, means_, precisions_cholesky_, covariance_type, weights_):
        """Estimate the weighted log-probabilities, log P(X | Z) + log weights.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)

        Returns
        -------
        weighted_log_prob : array, shape (n_samples, n_component)
        """
        return _estimate_log_gaussian_prob(X, means_, precisions_cholesky_, covariance_type) + _estimate_log_weights(weights_)

def _estimate_log_prob_resp(X, means_, precisions_cholesky_, covariance_type, weights_):
    """Estimate log probabilities and responsibilities for each sample.

    Compute the log probabilities, weighted log probabilities per
    component and responsibilities for each sample in X with respect to
    the current state of the model.

    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)

    Returns
    -------
    log_prob_norm : array, shape (n_samples,)
        log p(X)

    log_responsibilities : array, shape (n_samples, n_components)
        logarithm of the responsibilities
    """
    weighted_log_prob = _estimate_weighted_log_prob(X, means_, precisions_cholesky_, covariance_type, weights_)
    log_prob_norm = logsumexp(weighted_log_prob, axis=1)
    with np.errstate(under="ignore"):
        # ignore underflow
        log_resp = weighted_log_prob - log_prob_norm[:, jnp.newaxis]
    return log_prob_norm, log_resp

#####################################################


def gmm_patch_level_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('train_residual_multilayer')
    ################################################################################################
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    threshold_pixel = None
    
    gmm_soft_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    # if config.using_smoothed_filter_core:
    #     print("filter_size: ", filter_size.shape[0])
    #     resid_sq = smoothed_filter_core(smoothed_filter_size=filter_size.shape[0], residual=resid_sq)
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        # resid_sq_patch16 = jnp.clip(resid_sq_patch16, 0.000001, 1.0-0.000001)
        ### 预测属于clean的概率
        # if not config.using_gmm_means_threshold:
        #     _, log_resp_patch16 = _estimate_log_prob_resp(resid_sq_patch16, gmm_means_patch16, gmm_precisions_cholesky_patch16, gmm_covariance_type_num_patch16, gmm_weights_patch16)
        #     normalized_prob_values_patch16 = jnp.clip(jnp.exp(log_resp_patch16), 0.000001, 1.0-0.000001)
        #     mask_patch16 = jnp.clip(normalized_prob_values_patch16[:, gmm_means_patch16.argmin()], 0.000001, 1.0-0.000001)
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        gmm_soft_mask_mix.append(gmm_soft_mask_patch16)
        
    ### patch8
    if config.multilayer_patch8:
        resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 1)
        resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        # if not config.using_gmm_means_threshold:
        #     _, log_resp_patch8 = _estimate_log_prob_resp(resid_sq_patch8, gmm_means_patch8, gmm_precisions_cholesky_patch8, gmm_covariance_type_num_patch8, gmm_weights_patch8)
        #     normalized_prob_values_patch8 = jnp.clip(jnp.exp(log_resp_patch8), 0.000001, 1.0-0.000001)
        #     mask_patch8 = jnp.clip(normalized_prob_values_patch8[:, gmm_means_patch8.argmin()], 0.000001, 1.0-0.000001)
        if config.using_gmm_small_means_threshold:
            threshold_patch8 = gmm_means_patch8.min()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
        
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
            
        gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
        gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
        gmm_soft_mask_mix.append(gmm_soft_mask_patch8)
        
    ### patch4
    if config.multilayer_patch4:
        resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 1)
        resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        # if not config.using_gmm_means_threshold:
        #     _, log_resp_patch4 = _estimate_log_prob_resp(resid_sq_patch4, gmm_means_patch4, gmm_precisions_cholesky_patch4, gmm_covariance_type_num_patch4, gmm_weights_patch4)
        #     normalized_prob_values_patch4 = jnp.clip(jnp.exp(log_resp_patch4), 0.000001, 1.0-0.000001)
        #     mask_patch4 = jnp.clip(normalized_prob_values_patch4[:, gmm_means_patch4.argmin()], 0.000001, 1.0-0.000001)
        if config.using_gmm_small_means_threshold:
            threshold_patch4 = gmm_means_patch4.min()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
        gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                    
        gmm_soft_mask_mix.append(gmm_soft_mask_patch4)
        
    ### pixel
    if config.multilayer_pixel:
        mask_pixel_shape = resid_sq.shape
        resid_sq_pixel = resid_sq.reshape(-1, 1)
        
        # if not config.using_gmm_means_threshold:
        #     _, log_resp_pixel = _estimate_log_prob_resp(resid_sq_pixel, gmm_means_pixel, gmm_precisions_cholesky_pixel, gmm_covariance_type_num_pixel, gmm_weights_pixel)
        #     normalized_prob_values_pixel = jnp.exp(log_resp_pixel)
        #     mask_pixel = normalized_prob_values_pixel[:, gmm_means_pixel.argmin()] 
            
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:, 0]
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min() + gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min() + gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:,0]
            
        gmm_soft_mask_pixel = mask_pixel.reshape(mask_pixel_shape[:3])
        gmm_soft_mask_pixel = gmm_soft_mask_pixel[..., jnp.newaxis]
        
        gmm_soft_mask_mix.append(gmm_soft_mask_pixel)
    
    ### mix gmm mask
    if len(gmm_soft_mask_mix) >1:
        gmm_soft_mask_mix = jnp.concatenate(gmm_soft_mask_mix, axis=-1)
    else:
        gmm_soft_mask_mix = gmm_soft_mask_mix[0]
    gmm_soft_mask_mix = gmm_soft_mask_mix.mean(axis=-1)[..., jnp.newaxis]
    
    # ### threshold
    # threshold_h = 0.8
    # threshold_l = 0.2
    # gmm_soft_mask_mix = jnp.where(gmm_soft_mask_mix >= threshold_h, 1, gmm_soft_mask_mix)
    # gmm_soft_mask_mix = jnp.where(gmm_soft_mask_mix < threshold_l, 0, gmm_soft_mask_mix)
    
    return gmm_soft_mask_mix, threshold_patch16, threshold_patch8, threshold_patch4, threshold_pixel


def gmm_pixel_level_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_pixel_level_multilayer')
    ################################################################################################
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    pixel_level_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch7)
        
    ### patch5
    if config.multilayer_patch5:
        print('multilayer_patch5')
        resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch5 = gmm_means_patch5.min()
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_pixel)
        

    
    ### mix gmm mask, pixel level, 这一步用或操作，或者mean，两种都试试？
    if config.pixel_level_mask_mean:
        if len(pixel_level_mask_mix) >1:
            pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
        else:
            pixel_level_mask_mix = pixel_level_mask_mix[0]
        pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)
    
    elif config.pixel_level_mask_or:
        epsilon = 1e-3
        if len(pixel_level_mask_mix) >1:
            pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
        else:
            pixel_level_mask_mix = pixel_level_mask_mix[0]
        pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)
        pixel_level_mask_mix = jnp.where(pixel_level_mask_mix > epsilon, 1, 0)
    
    return pixel_level_mask_mix, threshold_patch7, threshold_patch5, threshold_patch3, threshold_pixel


def gmm_patchpixel_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    pixel_level_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch7)
        
    ### patch5
    if config.multilayer_patch5:
        print('multilayer_patch5')
        resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch5 = gmm_means_patch5.min()
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
            mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        # assert any(mask_patch3), "No implement method!"
            
        
        pixel_level_mask_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_pixel)
        

    
    ### mix gmm mask, pixel level, 这一步用或操作，或者mean，两种都试试？
    if config.pixel_level_mask_mean:
        if len(pixel_level_mask_mix) >1:
            pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
        else:
            pixel_level_mask_mix = pixel_level_mask_mix[0]
        # pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)  ## 这里先不mean，留着到最后和patch mask cat起来一起平均
    
    elif config.pixel_level_mask_or:
        epsilon = 1e-3
        if len(pixel_level_mask_mix) >1:
            pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
        else:
            pixel_level_mask_mix = pixel_level_mask_mix[0]
        pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)
        pixel_level_mask_mix = jnp.where(pixel_level_mask_mix > epsilon, 1, 0)   ## 或操作
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用patch的mask作为底板，和pixel的mask进行或操作：
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    
    patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        patch_level_mask_mix.append(gmm_soft_mask_patch16)
        
    ### patch8
    if config.multilayer_patch8:
        resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 1)
        resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch8 = gmm_means_patch8.min()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
        
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
            
        gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
        gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
        patch_level_mask_mix.append(gmm_soft_mask_patch8)
        
    ### patch4
    if config.multilayer_patch4:
        resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 1)
        resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch4 = gmm_means_patch4.min()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
        gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                    
        patch_level_mask_mix.append(gmm_soft_mask_patch4)
        
    
    ### 把patch mask进行与操作，作为patch层mask底板：
    if len(patch_level_mask_mix) >1:
        patch_level_mask_mix = jnp.concatenate(patch_level_mask_mix, axis=-1)
    else:
        patch_level_mask_mix = patch_level_mask_mix[0]
    
    
    ########----------------------------------------------#####################
    # ### 3.1 pixel mask 和patch mask 进行或操作：
    # patch_level_mask_mix = patch_level_mask_mix.mean(axis=-1, keepdims=True)
    # patch_level_mask_mix = jnp.where(patch_level_mask_mix > (1-epsilon), 1, 0)   ## 首先对patch_level_mask进行与操作
    
    # assert pixel_level_mask_mix.shape == patch_level_mask_mix.shape, "pixel mask != patch mask!!!"
    # pixel_patch_mask_mix = pixel_level_mask_mix + patch_level_mask_mix
    # pixel_patch_mask_mix = jnp.where(pixel_patch_mask_mix > epsilon, 1, 0)
    
    ### 3.2 pixel mask 和patch mask 进行平均：
    if config.multilevel_mask_mean:
        pixel_patch_mask_mix = jnp.concatenate([patch_level_mask_mix, pixel_level_mask_mix], axis=-1)
        pixel_patch_mask_mix = pixel_patch_mask_mix.mean(axis=-1, keepdims=True)
        print("pixel_patch_mask_mix.shape(mean):", pixel_patch_mask_mix.shape)
        
    elif config.multilevel_mask_vote:
        pixel_patch_mask_mix = jnp.concatenate([patch_level_mask_mix, pixel_level_mask_mix], axis=-1)
        pixel_patch_mask_mix = pixel_patch_mask_mix.sum(axis=-1, keepdims=True)
        print("pixel_patch_mask_mix.shape(sum):", pixel_patch_mask_mix.shape)
        pixel_patch_mask_mix = jnp.where(pixel_patch_mask_mix > config.multilevel_mask_vote_threshold, 1, 0)
    
    return pixel_patch_mask_mix, threshold_patch16, threshold_patch8, threshold_patch4, \
            threshold_patch3, threshold_patch5, threshold_patch7, threshold_pixel
            
            
def gmm_hierarchy_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        # gmm_means_patch8: jnp.ndarray, 
        # gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        # gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    # threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    hierarchy_mask = []
    # pixel_level_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        # pixel_level_mask_mix.append(mask_pixel)
        

    
    # ### mix gmm mask, pixel level, 这一步用或操作，或者mean，两种都试试？
    # if config.pixel_level_mask_mean:
    #     if len(pixel_level_mask_mix) >1:
    #         pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
    #     else:
    #         pixel_level_mask_mix = pixel_level_mask_mix[0]
    #     # pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)  ## 这里先不mean，留着到最后和patch mask cat起来一起平均
    
    # elif config.pixel_level_mask_or:
    #     epsilon = 1e-3
    #     if len(pixel_level_mask_mix) >1:
    #         pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
    #     else:
    #         pixel_level_mask_mix = pixel_level_mask_mix[0]
    #     pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)
    #     pixel_level_mask_mix = jnp.where(pixel_level_mask_mix > epsilon, 1, 0)   ## 或操作
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用于点亮patch7：
    threshold_patch16 = None
    # threshold_patch8 = None
    # threshold_patch4 = None
    
    # patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        # patch_level_mask_mix.append(gmm_soft_mask_patch16)
        
        inner_patch_mask = _robustnerf_inner_patch_mask(
        config.gmm_inner_patch_size, config.patch_size
        )
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16 * inner_patch_mask
    
    ### 3. patch16点亮patch7，patch7点亮patch3， patch3点亮pixel
    epsilon = 1e-3
    mask_pixel = jnp.concatenate([mask_pixel, mask_patch3], axis=-1)
    mask_pixel = mask_pixel.mean(axis=-1, keepdims=True)
    mask_pixel = jnp.where(mask_pixel > epsilon, 1, 0)   ## 或操作
    hierarchy_mask.append(mask_pixel)
    
    mask_patch3 = jnp.concatenate([mask_patch3, mask_patch7], axis=-1)
    mask_patch3 = mask_patch3.mean(axis=-1, keepdims=True)
    mask_patch3 = jnp.where(mask_patch3 > epsilon, 1, 0)   ## 或操作
    hierarchy_mask.append(mask_patch3)
    
    mask_patch7 = jnp.concatenate([mask_patch7, gmm_soft_mask_patch16], axis=-1)
    mask_patch7 = mask_patch7.mean(axis=-1, keepdims=True)
    mask_patch7 = jnp.where(mask_patch7 > epsilon, 1, 0)   ## 或操作
    hierarchy_mask.append(mask_patch7)
    
    hierarchy_mask = jnp.concatenate(hierarchy_mask, axis=-1)
    hierarchy_mask = hierarchy_mask.mean(axis=-1, keepdims=True)
    
    return hierarchy_mask, threshold_patch16, \
            threshold_patch3, threshold_patch7, threshold_pixel
    
def _robustnerf_inner_patch_mask(
    inner_patch_size, outer_patch_size, *, dtype=jnp.float32
):
  """Constructs binary mask for inner patch.

  Args:
    inner_patch_size: Size of the (square) inside patch.
    outer_patch_size: Size of the (square) outer patch.
    dtype: dtype for result

  Returns:
    Binary mask of shape (1, outer_patch_size, outer_patch_size, 1). Mask is
      1.0 for the center (inner_patch_size, inner_patch_size) square and 0.0
      elsewhere.
  """
  pad_size_lower = (outer_patch_size - inner_patch_size) // 2
  pad_size_upper = outer_patch_size - (inner_patch_size + pad_size_lower)
  mask = jnp.pad(
      jnp.ones((1, inner_patch_size, inner_patch_size, 1), dtype=dtype),
      (
          (0, 0),  # batch
          (pad_size_lower, pad_size_upper),  # height
          (pad_size_lower, pad_size_upper),  # width
          (0, 0),  # channels
      ),
  )
  return mask


def gmm_six_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    pixel_level_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch7)
        
    # ### patch5
    # if config.multilayer_patch5:
    #     print('multilayer_patch5')
    #     resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
    #     if config.using_gmm_small_means_threshold:
    #         threshold_patch5 = gmm_means_patch5.min()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
    #     elif config.using_gmm_both_means_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_half_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_onefourth_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        # pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        # assert any(mask_patch3), "No implement method!"
            
        
        pixel_level_mask_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_pixel)
        

    
    ### 1 3 7 平均：
    pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
    pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)  
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用patch的mask作为底板，和pixel的mask进行或操作：
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    
    patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        patch_level_mask_mix.append(gmm_soft_mask_patch16)
        
    ### patch8
    if config.multilayer_patch8:
        resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 1)
        resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch8 = gmm_means_patch8.min()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
        
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
            
        gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
        gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
        patch_level_mask_mix.append(gmm_soft_mask_patch8)
        
    ### patch4
    if config.multilayer_patch4:
        resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 1)
        resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch4 = gmm_means_patch4.min()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
        gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                    
        patch_level_mask_mix.append(gmm_soft_mask_patch4)
        
    
    ### 把patch mask进行与操作，作为patch层mask底板：
    if len(patch_level_mask_mix) >1:
        patch_level_mask_mix = jnp.concatenate(patch_level_mask_mix, axis=-1)
    else:
        patch_level_mask_mix = patch_level_mask_mix[0]
    
    
    ########----------------------------------------------#####################
    ### 3.2 pixel mask 和patch mask 进行平均：
    
    pixel_patch_mask_mix = jnp.concatenate([patch_level_mask_mix, pixel_level_mask_mix], axis=-1)
    pixel_patch_mask_mix = pixel_patch_mask_mix.mean(axis=-1, keepdims=True)
    print("pixel_patch_mask_mix.shape(mean):", pixel_patch_mask_mix.shape)
        
    
    
    return pixel_patch_mask_mix, threshold_patch16, threshold_patch8, threshold_patch4, \
            threshold_patch3, threshold_patch5, threshold_patch7, threshold_pixel
            
            
def gmm_seven_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    pixel_level_mask_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_patch7)
        
    # ### patch5
    # if config.multilayer_patch5:
    #     print('multilayer_patch5')
    #     resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
    #     if config.using_gmm_small_means_threshold:
    #         threshold_patch5 = gmm_means_patch5.min()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
    #     elif config.using_gmm_both_means_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_half_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_onefourth_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        # pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        # assert any(mask_patch3), "No implement method!"
            
        
        pixel_level_mask_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        pixel_level_mask_mix.append(mask_pixel)
        

    
    ### 1 3 7 平均：
    pixel_level_mask_mix = jnp.concatenate(pixel_level_mask_mix, axis=-1)
    pixel_level_mask_mix = pixel_level_mask_mix.mean(axis=-1, keepdims=True)  
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用patch的mask作为底板，和pixel的mask进行或操作：
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    
    patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        patch_level_mask_mix.append(gmm_soft_mask_patch16)
        
    ### patch8
    if config.multilayer_patch8:
        resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 1)
        resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch8 = gmm_means_patch8.min()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
        
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
            
        gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
        gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
        patch_level_mask_mix.append(gmm_soft_mask_patch8)
        
    ### patch4
    if config.multilayer_patch4:
        resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 1)
        resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch4 = gmm_means_patch4.min()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
        gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                    
        patch_level_mask_mix.append(gmm_soft_mask_patch4)
        
    
    ### 把patch mask进行与操作，作为patch层mask底板：
    if len(patch_level_mask_mix) >1:
        patch_level_mask_mix = jnp.concatenate(patch_level_mask_mix, axis=-1)
    else:
        patch_level_mask_mix = patch_level_mask_mix[0]
    
    patch_level_mask_mix = patch_level_mask_mix.mean(axis=-1, keepdims=True)  
    
    
    ########----------------------------------------------#####################
    ### 3.2 pixel mask 和patch mask 进行平均：
    
    pixel_patch_mask_mix = jnp.concatenate([patch_level_mask_mix, pixel_level_mask_mix], axis=-1)
    pixel_patch_mask_mix = pixel_patch_mask_mix.mean(axis=-1, keepdims=True)
    print("pixel_patch_mask_mix.shape(mean):", pixel_patch_mask_mix.shape)
        
    
    
    return pixel_patch_mask_mix, threshold_patch16, threshold_patch8, threshold_patch4, \
            threshold_patch3, threshold_patch5, threshold_patch7, threshold_pixel
            
            
def gmm_eight_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    patch_3_4_7_8_mix = []
    patch_1_16_mix = []
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        patch_3_4_7_8_mix.append(mask_patch7)
        
    # ### patch5
    # if config.multilayer_patch5:
    #     print('multilayer_patch5')
    #     resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
    #     if config.using_gmm_small_means_threshold:
    #         threshold_patch5 = gmm_means_patch5.min()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
    #     elif config.using_gmm_both_means_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_half_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_onefourth_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        # pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        # assert any(mask_patch3), "No implement method!"
            
        
        patch_3_4_7_8_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        patch_1_16_mix.append(mask_pixel)
        
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用patch的mask作为底板，和pixel的mask进行或操作：
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    
    # patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        patch_1_16_mix.append(gmm_soft_mask_patch16)
        
    ### patch8
    if config.multilayer_patch8:
        resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 1)
        resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch8 = gmm_means_patch8.min()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
        
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
            mask_patch8 = jnp.where(resid_sq_patch8 > threshold_patch8, 0, 1)[:,0]
            
            
        gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
        gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
        patch_3_4_7_8_mix.append(gmm_soft_mask_patch8)
        
    ### patch4
    if config.multilayer_patch4:
        resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 1)
        resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch4 = gmm_means_patch4.min()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:, 0]
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
            mask_patch4 = jnp.where(resid_sq_patch4 > threshold_patch4, 0, 1)[:,0]
            
        gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
        gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                    
        patch_3_4_7_8_mix.append(gmm_soft_mask_patch4)
        
    
    patch_3_4_7_8_mix = jnp.concatenate(patch_3_4_7_8_mix, axis=-1)
    patch_3_4_7_8_mix = patch_3_4_7_8_mix.mean(axis=-1, keepdims=True) 
    
    patch_1_16_mix = jnp.concatenate(patch_1_16_mix, axis=-1)
    
    ########----------------------------------------------#####################
    ### 3.2 pixel mask 和patch mask 进行平均：
    
    pixel_patch_mask_mix = jnp.concatenate([patch_1_16_mix, patch_3_4_7_8_mix], axis=-1)
    pixel_patch_mask_mix = pixel_patch_mask_mix.mean(axis=-1, keepdims=True)
    print("pixel_patch_mask_mix.shape(mean):", pixel_patch_mask_mix.shape)
        
    
    
    return pixel_patch_mask_mix, threshold_patch16, threshold_patch8, threshold_patch4, \
            threshold_patch3, threshold_patch5, threshold_patch7, threshold_pixel
            
            
def gmm_nine_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, loss_threshold: float, clean_means_ratio: float,
        gmm_means_patch16: jnp.ndarray, 
        gmm_means_patch8: jnp.ndarray, 
        gmm_means_patch4: jnp.ndarray, 
        gmm_means_patch7: jnp.ndarray, 
        gmm_means_patch5: jnp.ndarray, 
        gmm_means_patch3: jnp.ndarray, 
        gmm_means_pixel: jnp.ndarray, 
        config) -> jnp.ndarray:
    
    print('gmm_patchpixel_multilayer')
    ################################################################################################
    ### 1. 第一步先计算pixel精细化的mask。
    threshold_patch7 = None
    threshold_patch5 = None
    threshold_patch3 = None
    threshold_pixel = None
    
    patch_1_3_7_16_mix = []
    
    resid_sq = resid_sq.mean(axis=-1, keepdims=True)
    
    ### patch7
    if config.multilayer_patch7:
        print('multilayer_patch7')
        resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch7 = gmm_means_patch7.min()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
            mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
            
        
        patch_1_3_7_16_mix.append(mask_patch7)
        
    # ### patch5
    # if config.multilayer_patch5:
    #     print('multilayer_patch5')
    #     resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq)
        
    #     if config.using_gmm_small_means_threshold:
    #         threshold_patch5 = gmm_means_patch5.min()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
        
    #     elif config.using_gmm_both_means_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_half_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
    #     elif config.using_gmm_both_means_onefourth_threshold:
    #         threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
    #         mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
            
        
        # pixel_level_mask_mix.append(mask_patch5)
        
    ### patch3
    if config.multilayer_patch3:
        print('multilayer_patch3')
        resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch3 = gmm_means_patch3.min()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
            mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
            
        # assert any(mask_patch3), "No implement method!"
            
        
        patch_1_3_7_16_mix.append(mask_patch3)
        
    ### pixel
    if config.multilayer_pixel:
        print('multilayer_pixel')
        
        if config.using_gmm_small_means_threshold:
            threshold_pixel = gmm_means_pixel.min()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1) 
        
        elif config.using_gmm_both_means_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
            mask_pixel = jnp.where(resid_sq > threshold_pixel, 0, 1)
            
        
        patch_1_3_7_16_mix.append(mask_pixel)
        
    
    ########----------------------------------------------#####################
    ### 2. 计算patch，用patch的mask作为底板，和pixel的mask进行或操作：
    threshold_patch16 = None
    threshold_patch8 = None
    threshold_patch4 = None
    
    # patch_level_mask_mix = []
    
    ### patch16
    if config.multilayer_patch16:
        print('multilayer_patch16')
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        
        if config.using_gmm_small_means_threshold:
            threshold_patch16 = gmm_means_patch16.min()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]  
        
        elif config.using_gmm_both_means_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_half_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        elif config.using_gmm_both_means_onefourth_threshold:
            threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
            mask_patch16 = jnp.where(resid_sq_patch16 > threshold_patch16, 0, 1)[:,0]
            
        ### reshape回原形状
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        patch_1_3_7_16_mix.append(gmm_soft_mask_patch16)
        
    
        
    
    patch_1_3_7_16_mix = jnp.concatenate(patch_1_3_7_16_mix, axis=-1)
    patch_1_3_7_16_mix = patch_1_3_7_16_mix.mean(axis=-1, keepdims=True) 
        
    
    
    return patch_1_3_7_16_mix, threshold_patch16, threshold_patch8, threshold_patch4, \
            threshold_patch3, threshold_patch5, threshold_patch7, threshold_pixel