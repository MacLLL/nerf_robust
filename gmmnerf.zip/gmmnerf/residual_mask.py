# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Evaluation script."""

import functools
from os import path
import sys
import time

from absl import app
from flax.metrics import tensorboard
from flax.training import checkpoints
import gin
from internal import configs
from internal import datasets
from internal import image
from internal import models
from internal import raw_utils
from internal import ref_utils
from internal import train_utils
from internal import utils
from internal import vis
import jax
from jax import random
import jax.numpy as jnp
import numpy as np
from internal import robustnerf
from internal import gmm_robustnerf
import os
import json
import cv2

configs.define_common_flags()
jax.config.parse_flags_with_absl()
import numpy as np
from PIL import Image
from internal import gmmsoftmask
from internal.gmmsoftmask import smoothed_filter_core

# 1. 调整图像大小
def resize_image(image, patch_size):
    h, w = image.shape[:2]
    new_w = int((w // patch_size) * patch_size)  # 将宽度调整为 16 的整数倍
    new_h = int((h // patch_size) * patch_size)  # 将高度调整为 16 的整数倍
    resized_image = image[:new_h, :new_w, ...]
    return resized_image

# 2. 把图像切成小图像块
def patch_apart(image_height, image_width, tiny_patch_size, residual):
  '''
  把residual图像分成tiny patch
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  '''
  ###############
  # 生成固定的patch坐标，固定是为了方便输出residual的mask
  # 计算patch的行数和列数
  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T
  
  # 固定坐标的 patch 坐标
  fixed_patch_coordinates = np.array(list(patch_coordinates))

  # 计算对应的切片索引
  x_indices = (fixed_patch_coordinates[:, 0])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]
  y_indices = (fixed_patch_coordinates[:, 1])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]

  # 提取小图像块
  residual_patches = residual[y_indices[:, :, np.newaxis], x_indices[:, np.newaxis, :]]
  return residual_patches    

# 3. 把patch的mask拼成完整图像
#3.1 robustnerf的patch直接拼起来，不需要tail进行复制；
def robustnerf_reconstruct_patch(image_height, image_width, tiny_patch_size, reshaped_prob):
  '''
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  reshaped_prob: 要 reshape mask 的概率值
  '''
  # 16个patch。每个patch里有若干小patch
  # length = reshaped_prob.shape[0]
  # subset_data = reshaped_prob.reshape(shape0, length//shape0)

  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T

  # 将还原的图像块放入对应的位置
  _patch = jnp.zeros((image_height, image_width))  # 初始化一个空白图像
  for i in range(len(patch_coordinates)):
      # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
      x, y = patch_coordinates[i]
      tiny_patch = reshaped_prob[i][..., 0]
    #   _patch[:, y:y+patch_size, x:x+patch_size] = tiny_patch
      _patch = _patch.at[y:y+tiny_patch_size, x:x+tiny_patch_size].set(tiny_patch)
  return _patch
#3.2 gmm的mask需要拼起来。需要tail复制，从概率值复制成一个小块
def reconstruct_patch(image_height, image_width, tiny_patch_size, reshaped_prob):
  '''
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  reshaped_prob: 要 reshape mask 的概率值
  '''
  # 16个patch。每个patch里有若干小patch
  # length = reshaped_prob.shape[0]
  # subset_data = reshaped_prob.reshape(shape0, length//shape0)

  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T

  # 将还原的图像块放入对应的位置
  _patch = jnp.zeros((image_height, image_width))  # 初始化一个空白图像
  for i in range(len(patch_coordinates)):
      # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
      x, y = patch_coordinates[i]
      tiny_patch = jnp.tile(reshaped_prob[i][...,np.newaxis, np.newaxis], (tiny_patch_size, tiny_patch_size))
    #   _patch[:, y:y+patch_size, x:x+patch_size] = tiny_patch
      _patch = _patch.at[y:y+tiny_patch_size, x:x+tiny_patch_size].set(tiny_patch)
  return _patch


def main(unused_argv):
  config = configs.load_config(save_config=False)

  dataset = datasets.load_dataset('residual', config.data_dir, config)

  key = random.PRNGKey(20200823)
  _, state, render_eval_pfn, _, _ = train_utils.setup_model(config, key)

  if config.rawnerf_mode:
    postprocess_fn = dataset.metadata['postprocess_fn']
  else:
    postprocess_fn = lambda z: z

  if config.eval_raw_affine_cc:
    cc_fun = raw_utils.match_images_affine
  else:
    cc_fun = image.color_correct

  metric_harness = image.MetricHarness()

  last_step = 0
  out_dir = path.join(config.checkpoint_dir,
                      'path_renders' if config.render_path else 'test_preds')
  path_fn = lambda x: path.join(out_dir, x)

  if not config.eval_only_once:
    summary_writer = tensorboard.SummaryWriter(
        path.join(config.checkpoint_dir, 'eval'))
  while True:
    state = checkpoints.restore_checkpoint(config.checkpoint_dir, state)
    step = int(state.step)
    if step <= last_step:
      print(f'Checkpoint step {step} <= last step {last_step}, sleeping.')
      time.sleep(10)
      continue
    print(f'Evaluating checkpoint at step {step}.')
    if config.eval_save_output and (not utils.isdir(out_dir)):
      utils.makedirs(out_dir)

    num_eval = min(dataset.size, config.eval_dataset_limit)
    key = random.PRNGKey(0 if config.deterministic_showcase else step)
    perm = random.permutation(key, num_eval)
    showcase_indices = np.sort(perm[:config.num_showcase_images])

    # metrics = []
    # metrics_cc = []
    showcases = []
    render_times = []
    for idx in range(dataset.size):
      eval_start_time = time.time()
      batch = next(dataset)
      if idx >= num_eval:
        print(f'Skipping image {idx+1}/{dataset.size}')
        continue
      print(f'Evaluating image {idx+1}/{dataset.size}')
      
      # # yoda:
      # if idx not in [0, 10, 20, 27, 30, 40, 50, 54, 60, 65, 70, 80, 90, 100, 103, 105 ]:
      #   continue
      
      # crab:
      if idx not in [0, 1, 10, 20, 27, 30, 33, 40, 50, 54, 55, 60, 65, 70, 71, 80, 90, 100, 103, 105]:
        continue
      
      # # statue:
      # if idx % 10 != 0:
      #   continue
      
      # # android:
      # if idx % 10 != 0:
      #   continue
      
      rays = batch.rays
      train_frac = state.step / config.max_steps
      rendering = models.render_image(
          functools.partial(
              render_eval_pfn,
              state.params,
              train_frac,
          ),
          rays,
          None,
          config,
      )

      if jax.host_id() != 0:  # Only record via host 0.
        continue

      render_times.append((time.time() - eval_start_time))
      print(f'Rendered in {render_times[-1]:0.3f}s')

      # Cast to 64-bit to ensure high precision for color correction function.
      gt_rgb = np.array(batch.rgb, dtype=np.float64)
      rendering['rgb'] = np.array(rendering['rgb'], dtype=np.float64)

      cc_start_time = time.time()
      rendering['rgb_cc'] = cc_fun(rendering['rgb'], gt_rgb)
      print(f'Color corrected in {(time.time() - cc_start_time):0.3f}s')

      if not config.eval_only_once and idx in showcase_indices:
        showcase_idx = idx if config.deterministic_showcase else len(showcases)
        showcases.append((showcase_idx, rendering, batch))
      if not config.render_path:
        rgb = postprocess_fn(rendering['rgb'])
        rgb_cc = postprocess_fn(rendering['rgb_cc'])
        rgb_gt = postprocess_fn(gt_rgb)

        if config.eval_quantize_metrics:
          # Ensures that the images written to disk reproduce the metrics.
          rgb = np.round(rgb * 255) / 255
          rgb_cc = np.round(rgb_cc * 255) / 255

        if config.eval_crop_borders > 0:
          crop_fn = lambda x, c=config.eval_crop_borders: x[c:-c, c:-c]
          rgb = crop_fn(rgb)
          rgb_cc = crop_fn(rgb_cc)
          rgb_gt = crop_fn(rgb_gt)

        # metric = metric_harness(rgb, rgb_gt)
        # metric_cc = metric_harness(rgb_cc, rgb_gt)
        
        ############################################################### 计算robustnerf mask
        ## mask图片保存在这个目录下：
        mask_image_dir = config.checkpoint_dir + '/mask_image/'+f'mask_{(step)}_steps'
        if not os.path.exists(mask_image_dir):
          os.makedirs(mask_image_dir)
          
        resid_sq = (rgb - rgb_gt)**2
        error_per_pixel = jnp.mean(resid_sq, axis=-1, keepdims=True)  # f32[n,h,w,1]
        eval_loss_threshold = jnp.quantile(
          error_per_pixel, config.robustnerf_inlier_quantile
        )
        resid_sq_ = resize_image(resid_sq, config.patch_size)
        
        if config.enable_robustnerf_loss:
          resid_sq_robustnerf = patch_apart(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, residual=resid_sq_)
          # 用robustnerf计算mask
          robustnerf_mask_patch, _ = robustnerf.robustnerf_mask(resid_sq_robustnerf, eval_loss_threshold, 
                  config)
          robustnerf_mask = robustnerf_reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, reshaped_prob=robustnerf_mask_patch)
          # 保存图片
          robustnerf_mask_image = np.asarray((robustnerf_mask*255)).astype(np.uint8)
          robustnerf_mask_dir = mask_image_dir + '/robustnerf_mask'
          if not os.path.exists(robustnerf_mask_dir):
            os.makedirs(robustnerf_mask_dir)
          robustnerf_mask_file = robustnerf_mask_dir + f'/robustnerf_{idx:03d}.png'
          cv2.imwrite(robustnerf_mask_file, robustnerf_mask_image)
        
        ############################################################### 计算gmm mask
        gmm_coef_dir = config.checkpoint_dir + '/gmm_coef/train'
        if not os.path.exists(gmm_coef_dir):
          os.makedirs(gmm_coef_dir)
        # 指定 JSON 文件路径
        json_file_path = gmm_coef_dir + '/' + f'all_training_{(step)}_steps_gmm_coefficient.json'

        # 读取 JSON 文件
        with open(json_file_path, 'r') as json_file:
            json_data = json.load(json_file)

        # 从 JSON 数据中获取对应的 NumPy 数组
        gmm_means_patch16 = np.array(json_data['gmm_means_patch16'])
        
        gmm_means_patch8 = np.array(json_data['gmm_means_patch8'])
        
        gmm_means_patch4 = np.array(json_data['gmm_means_patch4'])
        
        gmm_means_pixel = np.array(json_data['gmm_means_pixel'])
        
        gmm_means_patch7 = np.array(json_data['gmm_means_patch7'])
        gmm_means_patch5 = np.array(json_data['gmm_means_patch5'])
        gmm_means_patch3 = np.array(json_data['gmm_means_patch3'])
        
        print("load from checkpoints!!")
        gmm_patch_level_mask_mix = []
        gmm_pixel_level_mask_mix = []
        
        filter_size = jnp.ones((1, 1))
        resid_sq_ = jnp.expand_dims(resid_sq_.mean(axis=-1, keepdims=True), axis=0)
        if config.using_smoothed_filter_core and False:
          if (step/config.max_steps) < 0.25 :
            filter_size = jnp.ones((9, 9))
          elif (step/config.max_steps) >= 0.25 and (step/config.max_steps) < 0.5 :
            filter_size = jnp.ones((7, 7))
          elif (step/config.max_steps) >= 0.5 and (step/config.max_steps) < 0.75 :
            filter_size = jnp.ones((5, 5))
          elif (step/config.max_steps) >= 0.75 :
            filter_size = jnp.ones((3, 3))
          resid_sq_ = smoothed_filter_core(smoothed_filter_size=filter_size.shape[0], residual=resid_sq_)[0]
        else:
          resid_sq_ = resid_sq_[0]
        
        resid_sq_patch16 = patch_apart(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, residual=resid_sq_)
        resid_sq_patch8 = patch_apart(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=8, residual=resid_sq_)
        resid_sq_patch4 = patch_apart(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=4, residual=resid_sq_)
        
        clean_means_ratio = 1 - jnp.exp(-config.coef_a * (step/config.max_steps))
        
        if config.patch_level_multilayer:
            print("patch_level_multilayer!")
            ### patch16
            if config.multilayer_patch16:
                print('multilayer_patch16')
                resid_sq_patch16_mean = resid_sq_patch16.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                  threshold_patch16 = gmm_means_patch16.min()
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]  
                elif config.using_gmm_both_means_threshold:
                  threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]
                
                ################################################################
                gmm_soft_mask_patch16 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, reshaped_prob=mask_patch16)
                gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch16)
                # 保存图片
                gmm_soft_mask_patch16_image = np.asarray((gmm_soft_mask_patch16*255)).astype(np.uint8)
                gmm_soft_mask_patch16_dir = mask_image_dir + '/gmm_patch_mask_patch16'
                if not os.path.exists(gmm_soft_mask_patch16_dir):
                  os.makedirs(gmm_soft_mask_patch16_dir)
                gmm_soft_mask_patch16_file = gmm_soft_mask_patch16_dir + f'/patch16_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch16_file, gmm_soft_mask_patch16_image)
                
            ### patch8
            if config.multilayer_patch8:
                print('multilayer_patch8')
                resid_sq_patch8_mean = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                    threshold_patch8 = gmm_means_patch8.min()
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:, 0]
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:,0]
                  
                ################################################################
                gmm_soft_mask_patch8 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=8, reshaped_prob=mask_patch8)
                gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch8)
                # 保存图片
                gmm_soft_mask_patch8_image = np.asarray((gmm_soft_mask_patch8*255)).astype(np.uint8)
                gmm_soft_mask_patch8_dir = mask_image_dir + '/gmm_patch_mask_patch8'
                if not os.path.exists(gmm_soft_mask_patch8_dir):
                  os.makedirs(gmm_soft_mask_patch8_dir)
                gmm_soft_mask_patch8_file = gmm_soft_mask_patch8_dir + f'/patch8_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch8_file, gmm_soft_mask_patch8_image)
                
            ### patch4
            if config.multilayer_patch4:
                print('multilayer_patch4')
                resid_sq_patch4_mean = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                    threshold_patch4 = gmm_means_patch4.min()
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:, 0]
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:,0]
                  
                ################################################################      
                      
                gmm_soft_mask_patch4 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=4, reshaped_prob=mask_patch4)
                gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch4)
                # 保存图片
                gmm_soft_mask_patch4_image = np.asarray((gmm_soft_mask_patch4*255)).astype(np.uint8)
                gmm_soft_mask_patch4_dir = mask_image_dir + '/gmm_patch_mask_patch4'
                if not os.path.exists(gmm_soft_mask_patch4_dir):
                  os.makedirs(gmm_soft_mask_patch4_dir)
                gmm_soft_mask_patch4_file = gmm_soft_mask_patch4_dir + f'/patch4_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch4_file, gmm_soft_mask_patch4_image)
                
            ### pixel
            if config.multilayer_pixel:
                mask_pixel_shape = resid_sq_.shape
                resid_sq_pixel = resid_sq_.mean(axis=-1).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率 
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                    threshold_pixel = gmm_means_pixel.min()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:, 0]
                elif config.using_gmm_both_means_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)[:,0]
                
                gmm_soft_mask_pixel = mask_pixel.reshape(mask_pixel_shape[:2])
                gmm_soft_mask_pixel = gmm_soft_mask_pixel[..., jnp.newaxis]
                
                
                gmm_patch_level_mask_mix.append(gmm_soft_mask_pixel)
                # 保存图片
                gmm_soft_mask_pixel_image = np.asarray((gmm_soft_mask_pixel*255)).astype(np.uint8)
                gmm_soft_mask_pixel_dir = mask_image_dir + '/gmm_patch_mask_pixel'
                if not os.path.exists(gmm_soft_mask_pixel_dir):
                  os.makedirs(gmm_soft_mask_pixel_dir)
                gmm_soft_mask_pixel_file = gmm_soft_mask_pixel_dir + f'/pixel_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_pixel_file, gmm_soft_mask_pixel_image)
            
            ### mix gmm patch level mask
            if len(gmm_patch_level_mask_mix) >1:
                gmm_patch_level_mask_mix = jnp.concatenate(gmm_patch_level_mask_mix, axis=-1)
            else:
                gmm_patch_level_mask_mix = gmm_patch_level_mask_mix[0]
            gmm_patch_level_mask_mix = gmm_patch_level_mask_mix.mean(axis=-1)[..., jnp.newaxis]
            
            gmm_patch_level_mask_mix_image = np.asarray((gmm_patch_level_mask_mix*255)).astype(np.uint8)
            gmm_patch_level_mask_mix_dir = mask_image_dir + '/gmm_patch_mask_mix'
            if not os.path.exists(gmm_patch_level_mask_mix_dir):
              os.makedirs(gmm_patch_level_mask_mix_dir)
            gmm_patch_level_mask_mix_file = gmm_patch_level_mask_mix_dir + f'/mix_{idx:03d}.png'
            cv2.imwrite(gmm_patch_level_mask_mix_file, gmm_patch_level_mask_mix_image)
        
        
        elif config.pixel_level_multilayer:
            print("pixel_level_multilayer!")
            resid_sq_ = jnp.expand_dims(resid_sq_, axis=0)
            
            ### patch7
            if config.multilayer_patch7:
                print('multilayer_patch7')
                resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch7 = gmm_means_patch7.min()
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch7)
                
                # 保存图片
                mask_patch7_image = np.asarray((mask_patch7*255)).astype(np.uint8)
                mask_patch7_dir = mask_image_dir + '/gmm_pixel_mask_patch7'
                if not os.path.exists(mask_patch7_dir):
                  os.makedirs(mask_patch7_dir)
                mask_patch7_file = mask_patch7_dir + f'/patch7_{idx:03d}.png'
                cv2.imwrite(mask_patch7_file, mask_patch7_image)
                
            ### patch5
            if config.multilayer_patch5:
                print('multilayer_patch5')
                resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch5 = gmm_means_patch5.min()
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch5)
                
                # 保存图片
                mask_patch5_image = np.asarray((mask_patch5*255)).astype(np.uint8)
                mask_patch5_dir = mask_image_dir + '/gmm_pixel_mask_patch5'
                if not os.path.exists(mask_patch5_dir):
                  os.makedirs(mask_patch5_dir)
                mask_patch5_file = mask_patch5_dir + f'/patch5_{idx:03d}.png'
                cv2.imwrite(mask_patch5_file, mask_patch5_image)
                
            ### patch3
            if config.multilayer_patch3:
                print('multilayer_patch3')
                resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch3 = gmm_means_patch3.min()
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch3)
                # 保存图片
                mask_patch3_image = np.asarray((mask_patch3*255)).astype(np.uint8)
                mask_patch3_dir = mask_image_dir + '/gmm_pixel_mask_patch3'
                if not os.path.exists(mask_patch3_dir):
                  os.makedirs(mask_patch3_dir)
                mask_patch3_file = mask_patch3_dir + f'/patch3_{idx:03d}.png'
                cv2.imwrite(mask_patch3_file, mask_patch3_image)
                
            ### pixel
            if config.multilayer_pixel:
                print('multilayer_pixel')
                resid_sq_pixel = resid_sq_[0]
                if config.using_gmm_small_means_threshold:
                    threshold_pixel = gmm_means_pixel.min()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_pixel)
                
                # 保存图片
                mask_pixel_image = np.asarray((mask_pixel*255)).astype(np.uint8)
                mask_pixel_dir = mask_image_dir + '/gmm_pixel_mask_pixel'
                if not os.path.exists(mask_pixel_dir):
                  os.makedirs(mask_pixel_dir)
                mask_pixel_file = mask_pixel_dir + f'/pixel_{idx:03d}.png'
                cv2.imwrite(mask_pixel_file, mask_pixel_image)

            
            ### mix gmm mask, pixel level, 这一步用或操作，或者mean，两种都试试？
            if config.pixel_level_mask_mean:
                if len(gmm_pixel_level_mask_mix) >1:
                    gmm_pixel_level_mask_mix = jnp.concatenate(gmm_pixel_level_mask_mix, axis=-1)
                else:
                    gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix[0]
                gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix.mean(axis=-1, keepdims=True)
            
            elif config.pixel_level_mask_or:
                epsilon = 1e-3
                if len(gmm_pixel_level_mask_mix) >1:
                    gmm_pixel_level_mask_mix = jnp.concatenate(gmm_pixel_level_mask_mix, axis=-1)
                else:
                    gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix[0]
                gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix.mean(axis=-1, keepdims=True)
                gmm_pixel_level_mask_mix = jnp.where(gmm_pixel_level_mask_mix > epsilon, 1, 0)
            
            pixel_level_mask_mix_image = np.asarray((gmm_pixel_level_mask_mix*255)).astype(np.uint8)
            pixel_level_mask_mix_dir = mask_image_dir + '/gmm_pixel_mask_mix'
            if not os.path.exists(pixel_level_mask_mix_dir):
              os.makedirs(pixel_level_mask_mix_dir)
            pixel_level_mask_mix_file = pixel_level_mask_mix_dir + f'/mix_{idx:03d}.png'
            cv2.imwrite(pixel_level_mask_mix_file, pixel_level_mask_mix_image)
            
        
        elif config.patchpixel_multilayer:
            print("patchpixel_multilayer!")
            
            ############-------------------------------#############
            ### 1. pixel level
            resid_sq_ = jnp.expand_dims(resid_sq_, axis=0)
            
            ### patch7
            if config.multilayer_patch7:
                print('multilayer_patch7')
                resid_sq_patch7 = smoothed_filter_core(smoothed_filter_size=7, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch7 = gmm_means_patch7.min()
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * gmm_means_patch7.max()
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch7.min()+gmm_means_patch7.max())
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch7 = clean_means_ratio * gmm_means_patch7.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch7.min()+gmm_means_patch7.max())
                    mask_patch7 = jnp.where(resid_sq_patch7 > threshold_patch7, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch7)
                
                # 保存图片
                mask_patch7_image = np.asarray((mask_patch7*255)).astype(np.uint8)
                mask_patch7_dir = mask_image_dir + '/pixel_level_mask_patch7'
                if not os.path.exists(mask_patch7_dir):
                  os.makedirs(mask_patch7_dir)
                mask_patch7_file = mask_patch7_dir + f'/patch7_{idx:03d}.png'
                cv2.imwrite(mask_patch7_file, mask_patch7_image)
                
            ### patch5
            if config.multilayer_patch5:
                print('multilayer_patch5')
                resid_sq_patch5 = smoothed_filter_core(smoothed_filter_size=5, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch5 = gmm_means_patch5.min()
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * gmm_means_patch5.max()
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch5.min()+gmm_means_patch5.max())
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch5 = clean_means_ratio * gmm_means_patch5.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch5.min()+gmm_means_patch5.max())
                    mask_patch5 = jnp.where(resid_sq_patch5 > threshold_patch5, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch5)
                
                # 保存图片
                mask_patch5_image = np.asarray((mask_patch5*255)).astype(np.uint8)
                mask_patch5_dir = mask_image_dir + '/pixel_level_mask_patch5'
                if not os.path.exists(mask_patch5_dir):
                  os.makedirs(mask_patch5_dir)
                mask_patch5_file = mask_patch5_dir + f'/patch5_{idx:03d}.png'
                cv2.imwrite(mask_patch5_file, mask_patch5_image)
                
            ### patch3
            if config.multilayer_patch3:
                print('multilayer_patch3')
                resid_sq_patch3 = smoothed_filter_core(smoothed_filter_size=3, residual=resid_sq_)[0]
                
                if config.using_gmm_small_means_threshold:
                    threshold_patch3 = gmm_means_patch3.min()
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * gmm_means_patch3.max()
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch3.min()+gmm_means_patch3.max())
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch3 = clean_means_ratio * gmm_means_patch3.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch3.min()+gmm_means_patch3.max())
                    mask_patch3 = jnp.where(resid_sq_patch3 > threshold_patch3, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_patch3)
                # 保存图片
                mask_patch3_image = np.asarray((mask_patch3*255)).astype(np.uint8)
                mask_patch3_dir = mask_image_dir + '/pixel_level_mask_patch3'
                if not os.path.exists(mask_patch3_dir):
                  os.makedirs(mask_patch3_dir)
                mask_patch3_file = mask_patch3_dir + f'/patch3_{idx:03d}.png'
                cv2.imwrite(mask_patch3_file, mask_patch3_image)
                
            ### pixel
            if config.multilayer_pixel:
                print('multilayer_pixel')
                resid_sq_pixel = resid_sq_[0]
                if config.using_gmm_small_means_threshold:
                    threshold_pixel = gmm_means_pixel.min()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1) 
                
                elif config.using_gmm_both_means_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * gmm_means_pixel.max()
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                elif config.using_gmm_both_means_half_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_pixel.min()+gmm_means_pixel.max())
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_pixel = clean_means_ratio * gmm_means_pixel.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_pixel.min()+gmm_means_pixel.max())
                    mask_pixel = jnp.where(resid_sq_pixel > threshold_pixel, 0, 1)
                    
                
                gmm_pixel_level_mask_mix.append(mask_pixel)
                
                # 保存图片
                mask_pixel_image = np.asarray((mask_pixel*255)).astype(np.uint8)
                mask_pixel_dir = mask_image_dir + '/pixel_level_mask_pixel'
                if not os.path.exists(mask_pixel_dir):
                  os.makedirs(mask_pixel_dir)
                mask_pixel_file = mask_pixel_dir + f'/pixel_{idx:03d}.png'
                cv2.imwrite(mask_pixel_file, mask_pixel_image)
                
            ### mix gmm mask, pixel level, 这一步用或操作，或者mean，两种都试试？
            if config.pixel_level_mask_mean:
              if len(gmm_pixel_level_mask_mix) >1:
                  gmm_pixel_level_mask_mix = jnp.concatenate(gmm_pixel_level_mask_mix, axis=-1)
              else:
                  gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix[0]
              # gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix.mean(axis=-1, keepdims=True)  ## 这里先不mean，留着到最后和patch mask cat起来一起平均
          
            elif config.pixel_level_mask_or:
              epsilon = 1e-3
              if len(gmm_pixel_level_mask_mix) >1:
                  gmm_pixel_level_mask_mix = jnp.concatenate(gmm_pixel_level_mask_mix, axis=-1)
              else:
                  gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix[0]
              gmm_pixel_level_mask_mix = gmm_pixel_level_mask_mix.mean(axis=-1, keepdims=True)
              gmm_pixel_level_mask_mix = jnp.where(gmm_pixel_level_mask_mix > epsilon, 1, 0)
              
              ### 保存图片
              pixel_level_mask_mix_image = np.asarray((gmm_pixel_level_mask_mix*255)).astype(np.uint8)
              pixel_level_mask_mix_dir = mask_image_dir + '/gmm_pixel_mask_mix'
              if not os.path.exists(pixel_level_mask_mix_dir):
                os.makedirs(pixel_level_mask_mix_dir)
              pixel_level_mask_mix_file = pixel_level_mask_mix_dir + f'/mix_{idx:03d}.png'
              cv2.imwrite(pixel_level_mask_mix_file, pixel_level_mask_mix_image)
                
            ### 2. 计算patch level mask
            print("patch_level_multilayer!")
            resid_sq_ = resid_sq_[0]
            ### patch16
            if config.multilayer_patch16:
                print('multilayer_patch16')
                resid_sq_patch16_mean = resid_sq_patch16.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                  threshold_patch16 = gmm_means_patch16.min()
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]  
                elif config.using_gmm_both_means_threshold:
                  threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * gmm_means_patch16.max()
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]
                elif config.using_gmm_both_means_half_threshold:
                  threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch16.min()+gmm_means_patch16.max())
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]
            
                elif config.using_gmm_both_means_onefourth_threshold:
                  threshold_patch16 = clean_means_ratio * gmm_means_patch16.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch16.min()+gmm_means_patch16.max())
                  mask_patch16 = jnp.where(resid_sq_patch16_mean > threshold_patch16, 0, 1)[:,0]
                ################################################################
                print("resid_sq_.shape:", resid_sq_.shape)
                print("mask_patch16.shape", mask_patch16.shape)
                gmm_soft_mask_patch16 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, reshaped_prob=mask_patch16)
                gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch16)
                # 保存图片
                gmm_soft_mask_patch16_image = np.asarray((gmm_soft_mask_patch16*255)).astype(np.uint8)
                gmm_soft_mask_patch16_dir = mask_image_dir + '/gmm_patch_mask_patch16'
                if not os.path.exists(gmm_soft_mask_patch16_dir):
                  os.makedirs(gmm_soft_mask_patch16_dir)
                gmm_soft_mask_patch16_file = gmm_soft_mask_patch16_dir + f'/patch16_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch16_file, gmm_soft_mask_patch16_image)
                
            ### patch8
            if config.multilayer_patch8:
                print('multilayer_patch8')
                resid_sq_patch8_mean = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                    threshold_patch8 = gmm_means_patch8.min()
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:, 0]
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * gmm_means_patch8.max()
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:,0]
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch8.min() + gmm_means_patch8.max())
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:,0]
        
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch8 = clean_means_ratio * gmm_means_patch8.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch8.min() + gmm_means_patch8.max())
                    mask_patch8 = jnp.where(resid_sq_patch8_mean > threshold_patch8, 0, 1)[:,0]
                ################################################################
                gmm_soft_mask_patch8 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=8, reshaped_prob=mask_patch8)
                gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch8)
                # 保存图片
                gmm_soft_mask_patch8_image = np.asarray((gmm_soft_mask_patch8*255)).astype(np.uint8)
                gmm_soft_mask_patch8_dir = mask_image_dir + '/gmm_patch_mask_patch8'
                if not os.path.exists(gmm_soft_mask_patch8_dir):
                  os.makedirs(gmm_soft_mask_patch8_dir)
                gmm_soft_mask_patch8_file = gmm_soft_mask_patch8_dir + f'/patch8_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch8_file, gmm_soft_mask_patch8_image)
                
            ### patch4
            if config.multilayer_patch4:
                print('multilayer_patch4')
                resid_sq_patch4_mean = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
                ##################################################################
                ### 预测属于clean的概率
                # 使用gmm means作为threshold
                if config.using_gmm_small_means_threshold:
                    threshold_patch4 = gmm_means_patch4.min()
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:, 0]
                
                elif config.using_gmm_both_means_threshold:
                    threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * gmm_means_patch4.max()
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:,0]
                  
                elif config.using_gmm_both_means_half_threshold:
                    threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.5 * (gmm_means_patch4.min() + gmm_means_patch4.max())
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:,0]
            
                elif config.using_gmm_both_means_onefourth_threshold:
                    threshold_patch4 = clean_means_ratio * gmm_means_patch4.min() + (1-clean_means_ratio) * 0.25 * (gmm_means_patch4.min() + gmm_means_patch4.max())
                    mask_patch4 = jnp.where(resid_sq_patch4_mean > threshold_patch4, 0, 1)[:,0]
                ################################################################      
                      
                gmm_soft_mask_patch4 = reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=4, reshaped_prob=mask_patch4)
                gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
                gmm_patch_level_mask_mix.append(gmm_soft_mask_patch4)
                # 保存图片
                gmm_soft_mask_patch4_image = np.asarray((gmm_soft_mask_patch4*255)).astype(np.uint8)
                gmm_soft_mask_patch4_dir = mask_image_dir + '/gmm_patch_mask_patch4'
                if not os.path.exists(gmm_soft_mask_patch4_dir):
                  os.makedirs(gmm_soft_mask_patch4_dir)
                gmm_soft_mask_patch4_file = gmm_soft_mask_patch4_dir + f'/patch4_{idx:03d}.png'
                cv2.imwrite(gmm_soft_mask_patch4_file, gmm_soft_mask_patch4_image)
                
            
            ### mix patch level mask:
            epsilon = 1e-3
            if len(gmm_patch_level_mask_mix) >1:
                gmm_patch_level_mask_mix = jnp.concatenate(gmm_patch_level_mask_mix, axis=-1)
            else:
                gmm_patch_level_mask_mix = gmm_patch_level_mask_mix[0]
            # gmm_patch_level_mask_mix = gmm_patch_level_mask_mix.mean(axis=-1, keepdims=True)
            # gmm_patch_level_mask_mix = jnp.where(gmm_patch_level_mask_mix > (1-epsilon), 1, 0)   ## 与操作
            
            ########----------------------------------------------#####################
            # ### 3.1 pixel mask 和patch mask 进行或操作：
            # gmm_patch_level_mask_mix = gmm_patch_level_mask_mix.mean(axis=-1, keepdims=True)
            # gmm_patch_level_mask_mix = jnp.where(gmm_patch_level_mask_mix > (1-epsilon), 1, 0)   ## 首先对patch_level_mask进行与操作
            
            # assert pixel_level_mask_mix.shape == patch_level_mask_mix.shape, "pixel mask != patch mask!!!"
            # pixel_patch_mask_mix = pixel_level_mask_mix + patch_level_mask_mix
            # pixel_patch_mask_mix = jnp.where(pixel_patch_mask_mix > epsilon, 1, 0)
            
            ### 3.2 pixel mask 和patch mask 进行平均：
            if config.multilevel_mask_mean:
                pixel_patch_mask_mix = jnp.concatenate([gmm_patch_level_mask_mix, gmm_pixel_level_mask_mix], axis=-1)
                pixel_patch_mask_mix = pixel_patch_mask_mix.mean(axis=-1, keepdims=True)
                print("pixel_patch_mask_mix.shape(mean):", pixel_patch_mask_mix.shape)
                
            elif config.multilevel_mask_vote:
                pixel_patch_mask_mix = jnp.concatenate([gmm_patch_level_mask_mix, gmm_pixel_level_mask_mix], axis=-1)
                pixel_patch_mask_mix = pixel_patch_mask_mix.sum(axis=-1, keepdims=True)
                print("pixel_patch_mask_mix.shape(sum):", pixel_patch_mask_mix.shape)
                pixel_patch_mask_mix = jnp.where(pixel_patch_mask_mix > config.multilevel_mask_vote_threshold, 1, 0)
            
            #############################################
            # ### 保存图片
            # gmm_patch_level_mask_mix_image = np.asarray((gmm_patch_level_mask_mix*255)).astype(np.uint8)
            # gmm_patch_level_mask_mix_dir = mask_image_dir + '/gmm_patch_mask_mix'
            # if not os.path.exists(gmm_patch_level_mask_mix_dir):
            #   os.makedirs(gmm_patch_level_mask_mix_dir)
            # gmm_patch_level_mask_mix_file = gmm_patch_level_mask_mix_dir + f'/mix_{idx:03d}.png'
            # cv2.imwrite(gmm_patch_level_mask_mix_file, gmm_patch_level_mask_mix_image)

            
            
            ### 保存图片
            pixel_patch_mix_image = np.asarray((pixel_patch_mask_mix*255)).astype(np.uint8)
            pixel_patch_mix_dir = mask_image_dir + '/pixel_patch_mix'
            if not os.path.exists(pixel_patch_mix_dir):
              os.makedirs(pixel_patch_mix_dir)
            pixel_patch_mix_file = pixel_patch_mix_dir + f'/mix_{idx:03d}.png'
            cv2.imwrite(pixel_patch_mix_file, pixel_patch_mix_image)
            
        ######################################
        
        elif config.gmm_and_robustnerf:
          print("gmm_and_robustnerf!")
          resid_sq_robustnerf = patch_apart(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, residual=resid_sq_)
          # 用gmm_robustnerf计算mask
          gmm_mask, _ = gmm_robustnerf.gmm_robustnerf_mask(
              resid_sq_robustnerf, clean_means_ratio,
              gmm_means_pixel,
              config
              )
          
          robustnerf_mask = robustnerf_reconstruct_patch(resid_sq_.shape[0], resid_sq_.shape[1], tiny_patch_size=16, reshaped_prob=gmm_mask)
          # 保存图片
          robustnerf_mask_image = np.asarray((robustnerf_mask*255)).astype(np.uint8)
          robustnerf_mask_dir = mask_image_dir + '/gmm_robustnerf_mask'
          if not os.path.exists(robustnerf_mask_dir):
            os.makedirs(robustnerf_mask_dir)
          robustnerf_mask_file = robustnerf_mask_dir + f'/gmm_robustnerf_{idx:03d}.png'
          cv2.imwrite(robustnerf_mask_file, robustnerf_mask_image)
          
          
          
    break
        ################################################################################




if __name__ == '__main__':
  with gin.config_scope('eval'):
    app.run(main)
