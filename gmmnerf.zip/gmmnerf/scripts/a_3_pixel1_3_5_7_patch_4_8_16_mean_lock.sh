#!/bin/bash
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

export CUDA_VISIBLE_DEVICES=0


#### other scene RobustNeRF
SCENE0=crab/0
SCENE1=yoda/0
SCENE2=t_balloon_statue/0
SCENE3=and-bot/0

EXPERIMENT1=a_3_pixel1_3_5_7_patch_4_8_16_mean_lock

DATA_DIR=/home/wyk/lava2/Dataset/RobustNerf

CHECKPOINT_DIR00=/home/wyk/lava2/Model/multinerf/ckpts/"$EXPERIMENT1"/"$SCENE0"
CHECKPOINT_DIR01=/home/wyk/lava2/Model/multinerf/ckpts/"$EXPERIMENT1"/"$SCENE1"
CHECKPOINT_DIR02=/home/wyk/lava2/Model/multinerf/ckpts/"$EXPERIMENT1"/"$SCENE2"
CHECKPOINT_DIR03=/home/wyk/lava2/Model/multinerf/ckpts/"$EXPERIMENT1"/"$SCENE3"

# If running one of the indoor scenes, add
# --gin_bindings="Config.factor = 2"

rm "$CHECKPOINT_DIR00"/*
python -m train \
  --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
  --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE0}'" \
  --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR00}'" \
  --logtostderr


rm "$CHECKPOINT_DIR01"/*
python -m train \
  --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
  --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE1}'" \
  --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR01}'" \
  --logtostderr

rm "$CHECKPOINT_DIR02"/*
python -m train \
  --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
  --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE2}'" \
  --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR02}'" \
  --logtostderr

rm "$CHECKPOINT_DIR03"/*
python -m train \
  --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
  --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE3}'" \
  --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR03}'" \
  --logtostderr


############################################################################

# python -m eval \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE0}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR00}'" \
#   --logtostderr

# python -m eval \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE1}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR01}'" \
#   --logtostderr

# python -m eval \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE2}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR02}'" \
#   --logtostderr

# python -m eval \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE3}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR03}'" \
#   --logtostderr

##############################################################################


# python -m residual_mask \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE0}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR00}'" \
#   --logtostderr

# python -m residual_mask \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE1}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR01}'" \
#   --logtostderr

# python -m residual_mask \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE2}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR02}'" \
#   --logtostderr

# python -m residual_mask \
#   --gin_configs=configs/a_3_pixel1_3_5_7_patch_4_8_16_mean_lock.gin \
#   --gin_bindings="Config.data_dir = '${DATA_DIR}/${SCENE3}'" \
#   --gin_bindings="Config.checkpoint_dir = '${CHECKPOINT_DIR03}'" \
#   --logtostderr