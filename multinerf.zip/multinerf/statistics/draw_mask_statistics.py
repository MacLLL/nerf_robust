import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 定义区间宽度
interval_width = 0.01
# 计算区间数量
num_intervals = int(1 / interval_width)

# 初始化区间内元素总和列表
easy_interval_sums = np.zeros(num_intervals)
# 初始化区间内元素总和列表
hard_interval_sums = np.zeros(num_intervals)
############################################################################################# easy
steps = {5000} #, 10000, 20000, 30000, 40000, 50000, 100000, 150000, 200000, 250000}
for step in steps:
    easy_interval_sums_file_name = f'easy_training_{step}_steps_residual_statistics_interval_sums.npy'
    easy_interval_sums = np.load('./easy/' + easy_interval_sums_file_name)

    print(easy_interval_sums.shape)
    print(easy_interval_sums.max(), easy_interval_sums.min())
    easy_interval_sums




    # 将NumPy数组转换为DataFrame
    df = pd.DataFrame(easy_interval_sums)

    # 保存DataFrame为Excel文件
    excel_file = easy_interval_sums_file_name.split('.')[0] + '.xlsx'
    df.to_excel(excel_file, index=False)

    print(f'Data saved to {excel_file}')
    ###########################################################################################


    ########################################################################################### hard
    hard_interval_sums_file_name = f'hard_training_{step}_steps_residual_statistics_interval_sums.npy'
    hard_interval_sums = np.load('./hard/' + hard_interval_sums_file_name)

    print(hard_interval_sums.shape)
    print(hard_interval_sums.max(), hard_interval_sums.min())
    hard_interval_sums

    # 将NumPy数组转换为DataFrame
    df = pd.DataFrame(hard_interval_sums)

    # 保存DataFrame为Excel文件
    excel_file = hard_interval_sums_file_name.split('.')[0] + '.xlsx'
    df.to_excel(excel_file, index=False)

    print(f'Data saved to {excel_file}')