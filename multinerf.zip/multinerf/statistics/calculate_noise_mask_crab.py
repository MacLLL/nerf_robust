## 为了得到数据中哪部分是noise像素，需要比较数据集中的clean和noise data。
## 比较误差大小，noise的误差要更大。
# 输出是每张图片的mask，存在npy中，标记训练数据中哪些是noise像素。
import sys  
sys.path.append('..')  
import os
import numpy as np
from internal import utils
from PIL import Image
import json
from pathlib import Path, PurePath
import matplotlib.pyplot as plt

def load_from_json(filename: Path):
    """Load a dictionary from a JSON filename.

    Args:
        filename: The filename to load from.
    """
    assert filename.suffix == ".json"
    with open(filename, encoding="UTF-8") as file:
        return json.load(file)
# configs 配置路径
data_dir = '/home/wyk/lava2/Model/multinerf/data/crab/0'
json_dir = PurePath(data_dir + "/transforms.json")
meta = load_from_json(json_dir)


# Load images.加载图片
image_names = []
for frame in meta["frames"]:
    filepath = PurePath(frame["file_path"])
    fname = filepath
    
    image_names.append(fname)
    
print(image_names.__len__())



images = [utils.load_img(x) for x in image_names]
images = np.stack(images, axis=0) / 255.

# import matplotlib.pyplot as plt
# print(images.shape)
# plt.imshow(images[0])
# plt.show()
# image_names[0]


# 需要读取两种图像，clean 和 clutter，然后对比，计算mask

clean_path = np.array([name for name in image_names if int(name.stem)<100])
# print(clean_path[-10:])
clutter_path = np.array([name for name in image_names if int(name.stem)>100])
# print(clutter_path[-10:])
mask_dir = data_dir + "/noise_mask"
if not os.path.exists(mask_dir):
    os.makedirs(mask_dir)


for clean_, clutter_ in zip(clean_path, clutter_path):
    if('999'+clean_.stem != clutter_.stem):
        print('clean 和 clutter 对应错误！')
        break
        
    clean_image = utils.load_img(clean_)
    clean_image = clean_image / 255.
    print("clean_image:", clean_image.shape)
    # plt.imshow(clean_image)
    # plt.show()
    
    clutter_image = utils.load_img(clutter_)
    clutter_image = clutter_image / 255.
    print("clutter_image: ", clutter_image.shape)
    # plt.imshow(clutter_image)
    # plt.show()
    
    residual = np.abs((clutter_image - clean_image).mean(axis=-1))
    print("residual: ", residual.shape)
    print(residual.min(), residual.max())
    print(residual)
    
    # noise_mask = np.zeros_like(residual)
    noise_mask = (residual>0.05).astype(int)
    print("noise_mask:",  noise_mask.shape)
    print(noise_mask)
    # plt.imshow(noise_mask)
    # plt.show()
    
    # plt.imshow(1-noise_mask)
    # plt.show()
    
    
    mask_file = PurePath( mask_dir + '/' + clean_.name ).with_suffix('.npy')
    print(mask_file)
    
    np.save(mask_file, noise_mask)
    
    
    # break
        

