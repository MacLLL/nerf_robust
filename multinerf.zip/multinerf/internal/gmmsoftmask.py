"""Computes gmm mask."""
from typing import Mapping, Tuple

from jax import lax
from jax import device_put
import jax.numpy as jnp
import jax
from jax import random
# from sklearn.mixture import GaussianMixture
import numpy as np
import jax.numpy as jnp
from sklearn.utils.extmath import row_norms

def patch_apart(image_height, image_width, tiny_patch_size, residual):
  '''
  把residual图像分成tiny patch
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  '''
  ###############
  # 生成固定的patch坐标，固定是为了方便输出residual的mask
  # 计算patch的行数和列数
  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T
  
  # 固定坐标的 patch 坐标
  fixed_patch_coordinates = np.array(list(patch_coordinates))

  # 计算对应的切片索引
  x_indices = (fixed_patch_coordinates[:, 0])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]
  y_indices = (fixed_patch_coordinates[:, 1])[:, np.newaxis] + np.arange(tiny_patch_size)[np.newaxis, :]

  # 提取小图像块
  residual_patches = residual[:, y_indices[:, :, np.newaxis], x_indices[:, np.newaxis, :]]
  return residual_patches    


def reconstruct_patch(image_height, image_width, tiny_patch_size, shape0, reshaped_prob):
  '''
  image_height, image_width: 输入residual图像的高、宽
  tiny_patch_size: tiny patch大小
  shape0: residual有几个patch, 取决于卡数量和batch size
  reshaped_prob: 要 reshape mask 的概率值
  '''
  # 16个patch。每个patch里有若干小patch
  length = reshaped_prob.shape[0]
  subset_data = reshaped_prob.reshape(shape0, length//shape0)

  num_patch_rows = image_height // tiny_patch_size
  num_patch_cols = image_width // tiny_patch_size
  # 生成所有可能的patch的左上角坐标
  rows = np.arange(num_patch_rows) * tiny_patch_size
  cols = np.arange(num_patch_cols) * tiny_patch_size
  # 使用NumPy的meshgrid函数生成所有可能的patch的左上角坐标
  patch_rows, patch_cols = np.meshgrid(rows, cols, indexing='ij')
  # 将patch的行坐标和列坐标展平，得到所有patch的左上角坐标
  patch_coordinates = np.vstack((patch_cols.ravel(), patch_rows.ravel())).T

  # 将还原的图像块放入对应的位置
  _patch = jnp.zeros((16, image_height, image_width))  # 初始化一个空白图像
  for i in range(len(patch_coordinates)):
      # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
      x, y = patch_coordinates[i]
      tiny_patch = jnp.tile(subset_data[:, i][...,np.newaxis, np.newaxis], (tiny_patch_size, tiny_patch_size))
    #   _patch[:, y:y+patch_size, x:x+patch_size] = tiny_patch
      _patch = _patch.at[:, y:y+tiny_patch_size, x:x+tiny_patch_size].set(tiny_patch)
  return _patch

def _asarray_validated(a, check_finite=True,
                       sparse_ok=False, objects_ok=False, mask_ok=False,
                       as_inexact=False):
    """
    Helper function for SciPy argument validation.

    Many SciPy linear algebra functions do support arbitrary array-like
    input arguments. Examples of commonly unsupported inputs include
    matrices containing inf/nan, sparse matrix representations, and
    matrices with complicated elements.

    Parameters
    ----------
    a : array_like
        The array-like input.
    check_finite : bool, optional
        Whether to check that the input matrices contain only finite numbers.
        Disabling may give a performance gain, but may result in problems
        (crashes, non-termination) if the inputs do contain infinities or NaNs.
        Default: True
    sparse_ok : bool, optional
        True if scipy sparse matrices are allowed.
    objects_ok : bool, optional
        True if arrays with dype('O') are allowed.
    mask_ok : bool, optional
        True if masked arrays are allowed.
    as_inexact : bool, optional
        True to convert the input array to a np.inexact dtype.

    Returns
    -------
    ret : ndarray
        The converted validated array.

    """
    if not sparse_ok:
        import scipy.sparse
        if scipy.sparse.issparse(a):
            msg = ('Sparse matrices are not supported by this function. '
                   'Perhaps one of the scipy.sparse.linalg functions '
                   'would work instead.')
            raise ValueError(msg)
    if not mask_ok:
        if np.ma.isMaskedArray(a):
            raise ValueError('masked arrays are not supported')
    toarray = jnp.asarray_chkfinite if check_finite else jnp.asarray
    a = toarray(a)
    if not objects_ok:
        if a.dtype is jnp.dtype('O'):
            raise ValueError('object arrays are not supported')
    if as_inexact:
        if not jnp.issubdtype(a.dtype, jnp.inexact):
            a = toarray(a, dtype=jnp.float_)
    return a


def logsumexp(a, axis=None, b=None, keepdims=False, return_sign=False):
    """Compute the log of the sum of exponentials of input elements.

    Parameters
    ----------
    a : array_like
        Input array.
    axis : None or int or tuple of ints, optional
        Axis or axes over which the sum is taken. By default `axis` is None,
        and all elements are summed.

        .. versionadded:: 0.11.0
    b : array-like, optional
        Scaling factor for exp(`a`) must be of the same shape as `a` or
        broadcastable to `a`. These values may be negative in order to
        implement subtraction.

        .. versionadded:: 0.12.0
    keepdims : bool, optional
        If this is set to True, the axes which are reduced are left in the
        result as dimensions with size one. With this option, the result
        will broadcast correctly against the original array.

        .. versionadded:: 0.15.0
    return_sign : bool, optional
        If this is set to True, the result will be a pair containing sign
        information; if False, results that are negative will be returned
        as NaN. Default is False (no sign information).

        .. versionadded:: 0.16.0

    Returns
    -------
    res : ndarray
        The result, ``np.log(np.sum(np.exp(a)))`` calculated in a numerically
        more stable way. If `b` is given then ``np.log(np.sum(b*np.exp(a)))``
        is returned.
    sgn : ndarray
        If return_sign is True, this will be an array of floating-point
        numbers matching res and +1, 0, or -1 depending on the sign
        of the result. If False, only one result is returned.

    See Also
    --------
    numpy.logaddexp, numpy.logaddexp2

    Notes
    -----
    NumPy has a logaddexp function which is very similar to `logsumexp`, but
    only handles two arguments. `logaddexp.reduce` is similar to this
    function, but may be less stable.

    Examples
    --------
    >>> import numpy as np
    >>> from scipy.special import logsumexp
    >>> a = np.arange(10)
    >>> logsumexp(a)
    9.4586297444267107
    >>> np.log(np.sum(np.exp(a)))
    9.4586297444267107

    With weights

    >>> a = np.arange(10)
    >>> b = np.arange(10, 0, -1)
    >>> logsumexp(a, b=b)
    9.9170178533034665
    >>> np.log(np.sum(b*np.exp(a)))
    9.9170178533034647

    Returning a sign flag

    >>> logsumexp([1,2],b=[1,-1],return_sign=True)
    (1.5413248546129181, -1.0)

    Notice that `logsumexp` does not directly support masked arrays. To use it
    on a masked array, convert the mask into zero weights:

    >>> a = np.ma.array([np.log(2), 2, np.log(3)],
    ...                  mask=[False, True, False])
    >>> b = (~a.mask).astype(int)
    >>> logsumexp(a.data, b=b), np.log(5)
    1.6094379124341005, 1.6094379124341005

    """
    a = _asarray_validated(a, check_finite=False)
    if b is not None:
        a, b = jnp.broadcast_arrays(a, b)
        if jnp.any(b == 0):
            a = a + 0.  # promote to at least float
            # a[b == 0] = -jnp.inf
            # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
            a = a.at[b == 0].set(-jnp.inf)

    a_max = jnp.amax(a, axis=axis, keepdims=True)

    if a_max.ndim > 0:
        # a_max[~jnp.isfinite(a_max)] = 0
        # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
        # a_max = a_max.at[~jnp.isfinite(a_max)].set(0)
        # 具体化布尔索引
        is_finite_mask = lax.convert_element_type(~jnp.isfinite(a_max), np.int32)
        # 使用具体化的布尔索引进行替换
        a_max = a_max.at[is_finite_mask].set(0)
        
    elif not jnp.isfinite(a_max):
        a_max = 0

    if b is not None:
        b = jnp.asarray(b)
        tmp = b * jnp.exp(a - a_max)
    else:
        tmp = jnp.exp(a - a_max)

    # suppress warnings about log of zero
    with np.errstate(divide='ignore'):
        s = jnp.sum(tmp, axis=axis, keepdims=keepdims)
        if return_sign:
            sgn = jnp.sign(s)
            s *= sgn  # /= makes more sense but we need zero -> zero
        out = jnp.log(s)

    if not keepdims:
        a_max = jnp.squeeze(a_max, axis=axis)
    out += a_max

    if return_sign:
        return out, sgn
    else:
        return out

######
#### 
# Gaussian mixture probability estimators
def _compute_log_det_cholesky(matrix_chol, covariance_type, n_features):
    """Compute the log-det of the cholesky decomposition of matrices.

    Parameters
    ----------
    matrix_chol : array-like
        Cholesky decompositions of the matrices.
        'full' : shape of (n_components, n_features, n_features)
        'tied' : shape of (n_features, n_features)
        'diag' : shape of (n_components, n_features)
        'spherical' : shape of (n_components,)

    covariance_type : {'full', 'tied', 'diag', 'spherical'}

    n_features : int
        Number of features.

    Returns
    -------
    log_det_precision_chol : array-like of shape (n_components,)
        The determinant of the precision matrix for each component.
    """
    # if covariance_type == 0: #"full"
    # assert covariance_type == 0, "covariance_type == \"full\" !"
    n_components, _, _ = matrix_chol.shape
    log_det_chol = jnp.sum(
        jnp.log(matrix_chol.reshape(n_components, -1)[:, :: n_features + 1]), 1
    )

    # elif covariance_type == 1: #"tied"
    #     log_det_chol = jnp.sum(jnp.log(jnp.diag(matrix_chol)))

    # elif covariance_type == 2: #"diag"
    #     log_det_chol = jnp.sum(jnp.log(matrix_chol), axis=1)

    # else:
    #     log_det_chol = n_features * (jnp.log(matrix_chol))

    return log_det_chol

def _estimate_log_gaussian_prob(X, means, precisions_chol, covariance_type):
    """Estimate the log Gaussian probability.

    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)

    means : array-like of shape (n_components, n_features)

    precisions_chol : array-like
        Cholesky decompositions of the precision matrices.
        'full' : shape of (n_components, n_features, n_features)
        'tied' : shape of (n_features, n_features)
        'diag' : shape of (n_components, n_features)
        'spherical' : shape of (n_components,)

    covariance_type : {'full', 'tied', 'diag', 'spherical'}

    Returns
    -------
    log_prob : array, shape (n_samples, n_components)
    """
    n_samples, n_features = X.shape
    n_components, _ = means.shape
    # The determinant of the precision matrix from the Cholesky decomposition
    # corresponds to the negative half of the determinant of the full precision
    # matrix.
    # In short: det(precision_chol) = - det(precision) / 2
    log_det = _compute_log_det_cholesky(precisions_chol, covariance_type, n_features)

    # if covariance_type == 0: #"full"
    # assert covariance_type == 0, "covariance_type == \"full\" !"
    log_prob = jnp.empty((n_samples, n_components))
    for k, (mu, prec_chol) in enumerate(zip(means, precisions_chol)):
        y = jnp.dot(X, prec_chol) - jnp.dot(mu, prec_chol)
        # log_prob[:, k] = jnp.sum(jnp.square(y), axis=1)
        # Instead of ``x[idx] = y``, use ``x = x.at[idx].set(y)`
        log_prob = log_prob.at[:, k].set(jnp.sum(jnp.square(y), axis=1))
            

    # elif covariance_type == 1: #"tied"
    #     log_prob = jnp.empty((n_samples, n_components))
    #     for k, mu in enumerate(means):
    #         y = jnp.dot(X, precisions_chol) - jnp.dot(mu, precisions_chol)
    #         log_prob[:, k] = jnp.sum(jnp.square(y), axis=1)

    # elif covariance_type == 2: #"diag"
    #     precisions = precisions_chol**2
    #     log_prob = (
    #         jnp.sum((means**2 * precisions), 1)
    #         - 2.0 * jnp.dot(X, (means * precisions).T)
    #         + jnp.dot(X**2, precisions.T)
    #     )

    # elif covariance_type == 3: #"spherical"
    #     precisions = precisions_chol**2
    #     log_prob = (
    #         jnp.sum(means**2, 1) * precisions
    #         - 2 * jnp.dot(X, means.T * precisions)
    #         + jnp.outer(row_norms(X, squared=True), precisions)
    #     )
    # Since we are using the precision of the Cholesky decomposition,
    # `- 0.5 * log_det_precision` becomes `+ log_det_precision_chol`
    return -0.5 * (n_features * jnp.log(2 * jnp.pi) + log_prob) + log_det


def _estimate_log_weights(weights_):
        return jnp.log(weights_)
    
def _estimate_weighted_log_prob(X, means_, precisions_cholesky_, covariance_type, weights_):
        """Estimate the weighted log-probabilities, log P(X | Z) + log weights.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)

        Returns
        -------
        weighted_log_prob : array, shape (n_samples, n_component)
        """
        return _estimate_log_gaussian_prob(X, means_, precisions_cholesky_, covariance_type) + _estimate_log_weights(weights_)

def _estimate_log_prob_resp(X, means_, precisions_cholesky_, covariance_type, weights_):
    """Estimate log probabilities and responsibilities for each sample.

    Compute the log probabilities, weighted log probabilities per
    component and responsibilities for each sample in X with respect to
    the current state of the model.

    Parameters
    ----------
    X : array-like of shape (n_samples, n_features)

    Returns
    -------
    log_prob_norm : array, shape (n_samples,)
        log p(X)

    log_responsibilities : array, shape (n_samples, n_components)
        logarithm of the responsibilities
    """
    weighted_log_prob = _estimate_weighted_log_prob(X, means_, precisions_cholesky_, covariance_type, weights_)
    log_prob_norm = logsumexp(weighted_log_prob, axis=1)
    with np.errstate(under="ignore"):
        # ignore underflow
        log_resp = weighted_log_prob - log_prob_norm[:, jnp.newaxis]
    return log_prob_norm, log_resp

#####################################################


def gmm_soft_mask(cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, gmm_means: jnp.ndarray, gmm_covariances: jnp.ndarray, gmm_weights: jnp.ndarray, gmm_precisions_cholesky: jnp.ndarray, gmm_covariance_type_num: int) -> jnp.ndarray:
    ## 方法1：分别计算每个像素
    if False:
        mask_shape = resid_sq.shape
        resid_sq = resid_sq.mean(axis=-1).reshape(-1, 1)
        # num_to_str = {0: 'full', 1: 'tied', 2: 'diag', 3: 'spherical'}
        # gmm_covariance_type = num_to_str[gmm_covariance_type_num]
        
        _, log_resp = _estimate_log_prob_resp(resid_sq, gmm_means, gmm_precisions_cholesky, gmm_covariance_type_num, gmm_weights)
        normalized_prob_values = jnp.exp(log_resp)
        
        mask = normalized_prob_values[:, gmm_means.argmin()] 
        gmm_soft_mask = mask.reshape(mask_shape[:3])
        gmm_soft_mask = gmm_soft_mask[..., jnp.newaxis]
        return gmm_soft_mask

    ################################################################################################
    ## 方法2 计算patch
    if True:
        mask_shape = resid_sq.shape
        resid_sq = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        resid_sq = jnp.clip(resid_sq, 0.000001, 1.0-0.000001)
        
        #####
        # key = random.PRNGKey(12345)  # Random seed is explicit in JAX
        # resid_sq__ = random.uniform(key, shape=resid_sq.shape)
        #####
        
        _, log_resp = _estimate_log_prob_resp(resid_sq, gmm_means, gmm_precisions_cholesky, gmm_covariance_type_num, gmm_weights)
        normalized_prob_values = jnp.clip(jnp.exp(log_resp), 0.000001, 1.0-0.000001)
        
        mask = jnp.clip(normalized_prob_values[:, gmm_means.argmin()], 0.000001, 1.0-0.000001)
        
        gmm_soft_mask = mask.reshape(-1, 1, 1)
        gmm_soft_mask = jnp.tile(gmm_soft_mask, (1, 16, 16))
        gmm_soft_mask = gmm_soft_mask[..., jnp.newaxis]
        
        # 设置阈值
        # threshold = 0.5
        # gmm_soft_mask = jnp.where(gmm_soft_mask >= threshold, 1, gmm_soft_mask)
        # gmm_soft_mask = jnp.where(gmm_soft_mask < threshold, 0, gmm_soft_mask)
        
        threshold_h = 0.8
        threshold_l = 0.2
        gmm_soft_mask = jnp.where(gmm_soft_mask >= threshold_h, 1, gmm_soft_mask)
        gmm_soft_mask = jnp.where(gmm_soft_mask < threshold_l, 0, gmm_soft_mask)
        
        return gmm_soft_mask
    
    ### 方法3 每张图片分别计算gmm模型参数
    if False:
        mask = []
        mask_shape = resid_sq.shape
        image_len = cam_idx.shape[0]
        for i in range(image_len):
            cam_id = cam_idx[i][0][0]
            resid_sq_ = resid_sq[i].mean(axis=-1).reshape(-1, 1)
            _, log_resp = _estimate_log_prob_resp(resid_sq_, gmm_means[cam_id], gmm_precisions_cholesky[cam_id], gmm_covariance_type_num[cam_id], gmm_weights[cam_id])
            normalized_prob_values = jnp.clip(jnp.exp(log_resp), 0.000001, 1.0-0.000001)
            mask_ = jnp.clip(normalized_prob_values[:, gmm_means[cam_id].argmin()], 0.000001, 1.0-0.000001)
            mask.append(mask_)
            
        mask = jnp.concatenate(mask)
        gmm_soft_mask = mask.reshape(mask_shape[:3])
        gmm_soft_mask = gmm_soft_mask[..., jnp.newaxis]
        return gmm_soft_mask
    
    ### 方法4 根据通道计算GMM模型
    if False:
        mask = []
        mask_shape = resid_sq.shape
        for i in range(mask_shape[-1]):
            resid_sq_ = resid_sq[..., i].reshape(-1, 1)
            _, log_resp = _estimate_log_prob_resp(resid_sq_, gmm_means[i], gmm_precisions_cholesky[i], gmm_covariance_type_num[i], gmm_weights[i])
            normalized_prob_values = jnp.clip(jnp.exp(log_resp), 0.000001, 1.0-0.000001)
            mask_ = jnp.clip(normalized_prob_values[:, gmm_means[i].argmin()], 0.000001, 1.0-0.000001)
            mask.append(mask_)
        
        #####    
        # mask = jnp.stack(mask, axis=-1)
        # gmm_soft_mask = mask.reshape(mask_shape)
        # gmm_soft_mask = gmm_soft_mask[..., jnp.newaxis]
        
        #####
        mask = jnp.stack(mask, axis=-1)
        ### 用一个统一的mask作用于3个通道
        mask = jnp.min(mask, axis = -1)
        gmm_soft_mask = mask.reshape(mask_shape[:3])
        gmm_soft_mask = gmm_soft_mask[..., jnp.newaxis]
        
        return gmm_soft_mask
        
        
        
        
        
    # prob = gmm_model.predict_proba(resid_sq) 
    # prob = prob[:,gmm_model.means_.argmin()] 
    # assert prob.shape == resid_sq.shape, " prob.shape != resid_sq.shape!!!!!!"
    # return prob

####################################################### 这种直接计算会导致除0，nan值，已经替换成sklearn库函数
    # # 计算每个新数据点属于每个分量的概率
    # num_components = len(gmm_means)
    # mask_shape = resid_sq.shape
    # resid_sq = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
    # num_new_data_points = len(resid_sq)
    # # prob_values = jnp.zeros((num_new_data_points, num_components))
    # prob_values = []

    # for i in range(num_components):
    #     # 计算多元正态分布的概率密度
    #     diff = resid_sq - gmm_means[i]
    #     cov = gmm_covariances[i]  # 协方差矩阵是1x1的
    #     cov_inv = 1.0 / cov  # 计算协方差矩阵的逆
    #     exponent = -0.5 * (diff ** 2) / cov  # 计算指数部分
    #     pdf_values = (1.0 / jnp.sqrt(2 * jnp.pi * cov)) * jnp.exp(exponent)
    #     # prob_values[:, i] = pdf_values * gmm_weights[i]
    #     # # 使用 index_update 更新 prob_values
    #     # prob_values = jax.ops.index_update(prob_values, jax.ops.index[:, i], pdf_values * gmm_weights[i])
    #     # 使用 at 方法更新 prob_values 的一列
    #     prob_values.append(pdf_values * gmm_weights[i])

    # # 计算每个新数据点属于所有分量的概率之和并归一化
    # cat_prob_values = jnp.concatenate(prob_values, axis=-1)
    # total_prob = jnp.sum(cat_prob_values, axis=1)
    # normalized_prob_values = cat_prob_values / total_prob[:, jnp.newaxis]

    # mask = normalized_prob_values[:, gmm_means.argmin()] 
    
##############################################################


def gmm_soft_mask_train_residual_patch16(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, 
        gmm_means_patch16: jnp.ndarray, 
        gmm_covariances_patch16: jnp.ndarray, 
        gmm_weights_patch16: jnp.ndarray, 
        gmm_precisions_cholesky_patch16: jnp.ndarray, 
        gmm_covariance_type_num_patch16: int,
        config) -> jnp.ndarray:
    

    ################################################################################################
    ## 方法2 计算patch
    if gmm_means_patch16 != None:
        mask_shape = resid_sq.shape
        resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
        resid_sq_patch16 = jnp.clip(resid_sq_patch16, 0.000001, 1.0-0.000001)
        
        #####
        # key = random.PRNGKey(12345)  # Random seed is explicit in JAX
        # resid_sq__ = random.uniform(key, shape=resid_sq.shape)
        #####
        
        _, log_resp_patch16 = _estimate_log_prob_resp(resid_sq_patch16, gmm_means_patch16, gmm_precisions_cholesky_patch16, gmm_covariance_type_num_patch16, gmm_weights_patch16)
        normalized_prob_values_patch16 = jnp.clip(jnp.exp(log_resp_patch16), 0.000001, 1.0-0.000001)
        
        mask_patch16 = jnp.clip(normalized_prob_values_patch16[:, gmm_means_patch16.argmin()], 0.000001, 1.0-0.000001)
        
        gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
        gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
        gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
        
        ### mask的不同计算方式
        # 1. 双阈值
        if config.dual_threshold:
            print('dual_threshold')
            threshold_h = config.dual_threshold_h # 0.8
            threshold_l = config.dual_threshold_l # 0.2
            gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 >= threshold_h, 1, gmm_soft_mask_patch16)
            gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 <  threshold_l, 0, gmm_soft_mask_patch16)
        
        # 2. 固定的阈值+指数衰减
        elif config.fixed_threshold_decay:
            print('fixed_threshold_decay')
            fixed_threshold = config.fixed_threshold
            decay_coef = config.decay_coef
            print('fixed_threshold, decay_coef = ', fixed_threshold, decay_coef)
            gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 >= fixed_threshold, gmm_soft_mask_patch16, gmm_soft_mask_patch16 ** decay_coef)
        
        return gmm_soft_mask_patch16
    
def gmm_soft_mask_train_residual_multilayer(
        cam_idx: jnp.ndarray, resid_sq: jnp.ndarray, 
        gmm_means_patch16: jnp.ndarray, 
        gmm_covariances_patch16: jnp.ndarray, 
        gmm_weights_patch16: jnp.ndarray, 
        gmm_precisions_cholesky_patch16: jnp.ndarray, 
        gmm_covariance_type_num_patch16: int,
        
        gmm_means_patch8: jnp.ndarray, 
        gmm_covariances_patch8: jnp.ndarray, 
        gmm_weights_patch8: jnp.ndarray, 
        gmm_precisions_cholesky_patch8: jnp.ndarray, 
        gmm_covariance_type_num_patch8: int,
        
        gmm_means_patch4: jnp.ndarray, 
        gmm_covariances_patch4: jnp.ndarray, 
        gmm_weights_patch4: jnp.ndarray, 
        gmm_precisions_cholesky_patch4: jnp.ndarray, 
        gmm_covariance_type_num_patch4: int,
        
        gmm_means_pixel: jnp.ndarray, 
        gmm_covariances_pixel: jnp.ndarray, 
        gmm_weights_pixel: jnp.ndarray, 
        gmm_precisions_cholesky_pixel: jnp.ndarray, 
        gmm_covariance_type_num_pixel: int,
        config) -> jnp.ndarray:
    
    print('train_residual_multilayer')
    ################################################################################################
    ## 方法2 计算patch
    if config.train_residual_multilayer:
        gmm_soft_mask_mix = []
        ### patch16
        if config.multilayer_patch16:
            print('multilayer_patch16')
            resid_sq_patch16 = resid_sq.mean(axis=(1, 2, 3)).reshape(-1, 1)
            resid_sq_patch16 = jnp.clip(resid_sq_patch16, 0.000001, 1.0-0.000001)
            ### 预测属于clean的概率
            _, log_resp_patch16 = _estimate_log_prob_resp(resid_sq_patch16, gmm_means_patch16, gmm_precisions_cholesky_patch16, gmm_covariance_type_num_patch16, gmm_weights_patch16)
            normalized_prob_values_patch16 = jnp.clip(jnp.exp(log_resp_patch16), 0.000001, 1.0-0.000001)
            mask_patch16 = jnp.clip(normalized_prob_values_patch16[:, gmm_means_patch16.argmin()], 0.000001, 1.0-0.000001)
            ### reshape回原形状
            gmm_soft_mask_patch16 = mask_patch16.reshape(-1, 1, 1)
            gmm_soft_mask_patch16 = jnp.tile(gmm_soft_mask_patch16, (1, 16, 16))
            gmm_soft_mask_patch16 = gmm_soft_mask_patch16[..., jnp.newaxis]
            
            ### mask的不同计算方式
            # 1. 单阈值
            if config.single_threshold:
                threshold = config.single_threshold_l # 0.2
                gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 < threshold, 0, gmm_soft_mask_patch16)
            
            # 2. 双阈值
            elif config.dual_threshold:
                print('dual_threshold')
                threshold_h = config.dual_threshold_h # 0.8
                threshold_l = config.dual_threshold_l # 0.2
                gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 >= threshold_h, 1, gmm_soft_mask_patch16)
                gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 < threshold_l, 0, gmm_soft_mask_patch16)
            
            # 3. 固定的阈值+指数衰减
            elif config.fixed_threshold_decay:
                print('fixed_threshold_decay')
                fixed_threshold = config.fixed_threshold
                decay_coef = config.decay_coef
                print('fixed_threshold, decay_coef = ', fixed_threshold, decay_coef)
                gmm_soft_mask_patch16 = jnp.where(gmm_soft_mask_patch16 >= fixed_threshold, gmm_soft_mask_patch16, gmm_soft_mask_patch16 ** decay_coef)
            
            gmm_soft_mask_mix.append(gmm_soft_mask_patch16)
            
        ### patch8
        if config.multilayer_patch8:
            resid_sq_patch8 = patch_apart(16, 16, 8, resid_sq).reshape(-1, 8, 8, 3)
            resid_sq_patch8 = resid_sq_patch8.mean(axis=(1, 2, 3)).reshape(-1, 1)
            
            _, log_resp_patch8 = _estimate_log_prob_resp(resid_sq_patch8, gmm_means_patch8, gmm_precisions_cholesky_patch8, gmm_covariance_type_num_patch8, gmm_weights_patch8)
            normalized_prob_values_patch8 = jnp.clip(jnp.exp(log_resp_patch8), 0.000001, 1.0-0.000001)
            mask_patch8 = jnp.clip(normalized_prob_values_patch8[:, gmm_means_patch8.argmin()], 0.000001, 1.0-0.000001)
            
            gmm_soft_mask_patch8 = reconstruct_patch(16, 16, 8, resid_sq.shape[0], mask_patch8)
            gmm_soft_mask_patch8 = gmm_soft_mask_patch8[..., jnp.newaxis]
            
            ### mask的不同计算方式
            # 1. 单阈值
            if config.single_threshold:
                threshold = config.single_threshold_l # 0.2
                gmm_soft_mask_patch8 = jnp.where(gmm_soft_mask_patch8 < threshold, 0, gmm_soft_mask_patch8)
                
            # 2. 双阈值
            if config.dual_threshold:
                print('dual_threshold')
                threshold_h = config.dual_threshold_h # 0.8
                threshold_l = config.dual_threshold_l # 0.2
                gmm_soft_mask_patch8 = jnp.where(gmm_soft_mask_patch8 >= threshold_h, 1, gmm_soft_mask_patch8)
                gmm_soft_mask_patch8 = jnp.where(gmm_soft_mask_patch8 <  threshold_l, 0, gmm_soft_mask_patch8)
            
            # 3. 固定的阈值+指数衰减
            elif config.fixed_threshold_decay:
                print('fixed_threshold_decay')
                fixed_threshold = config.fixed_threshold
                decay_coef = config.decay_coef
                print('fixed_threshold, decay_coef = ', fixed_threshold, decay_coef)
                gmm_soft_mask_patch8 = jnp.where(gmm_soft_mask_patch8 >= fixed_threshold, gmm_soft_mask_patch8, gmm_soft_mask_patch8 ** decay_coef)
                
            gmm_soft_mask_mix.append(gmm_soft_mask_patch8)
            
        ### patch4
        if config.multilayer_patch4:
            resid_sq_patch4 = patch_apart(16, 16, 4, resid_sq).reshape(-1, 4, 4, 3)
            resid_sq_patch4 = resid_sq_patch4.mean(axis=(1, 2, 3)).reshape(-1, 1)
            
            _, log_resp_patch4 = _estimate_log_prob_resp(resid_sq_patch4, gmm_means_patch4, gmm_precisions_cholesky_patch4, gmm_covariance_type_num_patch4, gmm_weights_patch4)
            normalized_prob_values_patch4 = jnp.clip(jnp.exp(log_resp_patch4), 0.000001, 1.0-0.000001)
            mask_patch4 = jnp.clip(normalized_prob_values_patch4[:, gmm_means_patch4.argmin()], 0.000001, 1.0-0.000001)
            
            gmm_soft_mask_patch4 = reconstruct_patch(16, 16, 4, resid_sq.shape[0], mask_patch4)
            gmm_soft_mask_patch4 = gmm_soft_mask_patch4[..., jnp.newaxis]
            
            ### mask的不同计算方式
            # 1. 单阈值
            if config.single_threshold:
                threshold = config.single_threshold_l # 0.2
                gmm_soft_mask_patch4 = jnp.where(gmm_soft_mask_patch4 < threshold, 0, gmm_soft_mask_patch4)
                
            # 2. 双阈值
            if config.dual_threshold:
                print('dual_threshold')
                threshold_h = config.dual_threshold_h # 0.8
                threshold_l = config.dual_threshold_l # 0.2
                gmm_soft_mask_patch4 = jnp.where(gmm_soft_mask_patch4 >= threshold_h, 1, gmm_soft_mask_patch4)
                gmm_soft_mask_patch4 = jnp.where(gmm_soft_mask_patch4 <  threshold_l, 0, gmm_soft_mask_patch4)
            
            # 3. 固定的阈值+指数衰减
            elif config.fixed_threshold_decay:
                print('fixed_threshold_decay')
                fixed_threshold = config.fixed_threshold
                decay_coef = config.decay_coef
                print('fixed_threshold, decay_coef = ', fixed_threshold, decay_coef)
                gmm_soft_mask_patch4 = jnp.where(gmm_soft_mask_patch4 >= fixed_threshold, gmm_soft_mask_patch4, gmm_soft_mask_patch4 ** decay_coef)
                
            gmm_soft_mask_mix.append(gmm_soft_mask_patch4)
            
        ### pixel
        if config.multilayer_pixel:
            mask_pixel_shape = resid_sq.shape
            resid_sq_pixel = resid_sq.mean(axis=-1).reshape(-1, 1)
            
            _, log_resp_pixel = _estimate_log_prob_resp(resid_sq_pixel, gmm_means_pixel, gmm_precisions_cholesky_pixel, gmm_covariance_type_num_pixel, gmm_weights_pixel)
            normalized_prob_values_pixel = jnp.exp(log_resp_pixel)
            
            mask_pixel = normalized_prob_values_pixel[:, gmm_means_pixel.argmin()] 
            gmm_soft_mask_pixel = mask_pixel.reshape(mask_pixel_shape[:3])
            gmm_soft_mask_pixel = gmm_soft_mask_pixel[..., jnp.newaxis]
            
            ### mask的不同计算方式
            # 1. 单阈值
            if config.single_threshold:
                threshold = config.single_threshold_l # 0.2
                gmm_soft_mask_pixel = jnp.where(gmm_soft_mask_pixel < threshold, 0, gmm_soft_mask_pixel)
                
            # 2. 双阈值
            if config.dual_threshold:
                print('dual_threshold')
                threshold_h = config.dual_threshold_h # 0.8
                threshold_l = config.dual_threshold_l # 0.2
                gmm_soft_mask_pixel = jnp.where(gmm_soft_mask_pixel >= threshold_h, 1, gmm_soft_mask_pixel)
                gmm_soft_mask_pixel = jnp.where(gmm_soft_mask_pixel <  threshold_l, 0, gmm_soft_mask_pixel)
            
            # 3. 固定的阈值+指数衰减
            elif config.fixed_threshold_decay:
                print('fixed_threshold_decay')
                fixed_threshold = config.fixed_threshold
                decay_coef = config.decay_coef
                print('fixed_threshold, decay_coef = ', fixed_threshold, decay_coef)
                gmm_soft_mask_pixel = jnp.where(gmm_soft_mask_pixel >= fixed_threshold, gmm_soft_mask_pixel, gmm_soft_mask_pixel ** decay_coef)
            
            gmm_soft_mask_mix.append(gmm_soft_mask_pixel)
        
        ### mix gmm mask
        if len(gmm_soft_mask_mix) >1:
            gmm_soft_mask_mix = jnp.concatenate(gmm_soft_mask_mix, axis=-1)
        else:
            gmm_soft_mask_mix = gmm_soft_mask_mix[0]
        gmm_soft_mask_mix = gmm_soft_mask_mix.mean(axis=-1)[..., jnp.newaxis]
        
        # ### threshold
        # threshold_h = 0.8
        # threshold_l = 0.2
        # gmm_soft_mask_mix = jnp.where(gmm_soft_mask_mix >= threshold_h, 1, gmm_soft_mask_mix)
        # gmm_soft_mask_mix = jnp.where(gmm_soft_mask_mix < threshold_l, 0, gmm_soft_mask_mix)
        
        return gmm_soft_mask_mix